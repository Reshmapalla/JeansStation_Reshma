using JeansAppAPI.Entities;
using JeansAppAPI.Repository;
using Moq;

namespace APITestProject
{
    public class ProductTest
    {
        private readonly Mock<IProductRepository> productService;

        public ProductTest()
        {
            this.productService = new Mock<IProductRepository>();
        }

        [Fact]
        public void Test_GetProductList()
        {
            var productList=GetProductsdata();
            productService.Setup(x => x.GetAllProducts()).Returns(productList);
            var result=productService.Object;//moq service
            var productResult = result.GetAllProducts().Result.ToList();
            Assert.NotNull(productResult);
            Assert.Equal(productList.Result.Count, productList.Result.Count);

        }
        [Fact]
        public void Test_GetProductById()
        {
            // Arrange
            var productId = "1";
            var product = new Product
            {
                ProductId = productId,
                ProductName = "skinnyJeans",
                Price = 2000,
                CategoryId = "C0001",
                BrandId = "B0001",
                Color = "Black",
                Size = "32"
            };

            productService.Setup(x => x.GetProductById(productId)).ReturnsAsync(product);

            // Act
            var result = productService.Object.GetProductById(productId).Result;

            // Assert
            Assert.NotNull(result);
            Assert.Equal(productId, result.ProductId);
        }

        [Fact]
        public void Test_AddProduct()
        {
            // Arrange
            var product = new Product
            {
                ProductId = "P1234",
                ProductName = "New Jeans",
                Price = 2500,
                CategoryId = "C0004",
                BrandId = "B0004",
                Color = "Grey",
                Size = "38"
            };

            productService.Setup(x => x.AddProduct(product)).Returns(Task.CompletedTask);

            // Act
            var result = productService.Object.AddProduct(product);

            // Assert
            Assert.NotNull(result);
            productService.Verify(x => x.AddProduct(product), Times.Once());
        }
        [Fact]
        public void Test_UpdateProduct()
        {
            // Arrange
            var product = new Product
            {
                ProductId = "1",
                ProductName = "Updated Jeans",
                Price = 2200,
                CategoryId = "C0001",
                BrandId = "B0001",
                Color = "Black",
                Size = "32"
            };

            productService.Setup(x => x.Update(product)).Returns(Task.CompletedTask);

            // Act
            var result = productService.Object.Update(product);

            // Assert
            Assert.NotNull(result);
            productService.Verify(x => x.Update(product), Times.Once());
        }
        [Fact]
        public void Test_DeleteProduct()
        {
            // Arrange
            var productId = "1";

            productService.Setup(x => x.Delete(productId)).Returns(Task.CompletedTask);

            // Act
            var result = productService.Object.Delete(productId);

            // Assert
            Assert.NotNull(result);
            productService.Verify(x => x.Delete(productId), Times.Once());
        }





        private Task<List<Product>> GetProductsdata()
        {
            List<Product> products = new List<Product>
            {
                new Product
                {
                    ProductId="1",
                    ProductName="skinnyJeans",
                    Price=2000,
                    CategoryId="C0001",
                    BrandId="B0001",
                    Color="Black",
                    Size="32",
                },
                new Product
                {
                    ProductId="2",
                    ProductName="Loose Jeans",
                    Price=2000,
                    CategoryId="C0002",
                    BrandId="B0002",
                    Color="Blue",
                    Size="34",
                },
                new Product
                {
                    ProductId="3",
                    ProductName="Bootcut Jeans",
                    Price=2000,
                    CategoryId="C0003",
                    BrandId="B0003",
                    Color="Brown",
                    Size="36",
                }
            };
            return Task.Run(() =>
            {
                return products;
            });
        }
    }
}