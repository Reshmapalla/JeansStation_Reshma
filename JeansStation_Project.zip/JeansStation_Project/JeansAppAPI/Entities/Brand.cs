﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace JeansAppAPI.Entities
{
    public class Brand
    {
        [Key]
        public string BrandId { get; set; }
        [Required(ErrorMessage = "Product Name is required.")]
        [Column(TypeName = "varchar")]
        [StringLength(30)]
        public string BrandName { get; set; }
    }
}
