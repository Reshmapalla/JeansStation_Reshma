﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace JeansAppAPI.Entities
{
    public class CartItem
    {
        [Key]

        public string CartId { get; set; }

        
        public string ProductId { get; set; }

        public string UserId { get; set; }

        [Required(ErrorMessage = "Quantity is required.")]
        public int Quantity { get; set; }

       

        // Derived property for total price, if you want to store it.
        [Column(TypeName = "decimal(18,2)")]
        public double TotalPrice { get; set; }

        // Navigation properties
       

        [ForeignKey("ProductId")]
        [JsonIgnore]
        public Product? Product { get; set; }
        [ForeignKey("UserId")]
        [JsonIgnore]
        public User? User { get; set; }

    }
}

