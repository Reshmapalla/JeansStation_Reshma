﻿namespace JeansAppAPI.Models
{
    public class OrderDTO
    {
        public Guid OrderId { get; set; }
        public string Address { get; set; }
        public double TotalPrice { get; set; }
        public string OrderStatus { get; set; }
        public DateTime OrderDate { get; set; }
        public DateTime DeliveryDate { get; set; }

        // Transaction details
        public string TransactionMethod { get; set; }
        public string TransactionStatus { get; set; }
        public DateTime TransactionDate { get; set; }
        // User details
        public string UserId { get; set; } // ID of the user who placed the order
        public string UserName { get; set; }

        // Order Items
        public List<OrderItemDTO> OrderItems { get; set; }
    }
}
