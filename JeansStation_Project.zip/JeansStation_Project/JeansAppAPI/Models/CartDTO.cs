﻿namespace JeansAppAPI.Models
{
    public class CartDTO
    {
        public string ProductId { get; set; }   
        public string CartId { get ; set; }
        public string? Size { get; set; }
        public string ProductName { get; set; }
        public double Discount { get; set; }
      
        public double Price { get; set; }
        public int Quantity { get; set; }
        public double TotalPrice { get; set; }

    }
}
