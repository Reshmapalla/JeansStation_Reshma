﻿namespace JeansAppAPI.Models
{
    public class ProductDTO
    {
       public string ProductId { get; set; }
        public string ProductName { get; set; }
        public double Price { get; set; }
        public string BrandName { get; set; }
        public string CategoryName { get; set; }
        public string Color { get; set; }
        public string Size { get; set; }
        public double Discount { get; set; }
      
    }
}
