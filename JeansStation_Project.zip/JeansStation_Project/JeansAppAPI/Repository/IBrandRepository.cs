﻿using JeansAppAPI.Entities;

namespace JeansAppAPI.Repository
{
    public interface IBrandRepository
    {
        Task AddBrand(Brand Brand);


        Task<List<Brand>> GetAllBrands();

        Task<Brand> GetBrandById(string BrandId);

        Task<Brand> GetBrandByBrandName(string Name);


        Task UpdateBrand(Brand Brand);


        Task DeleteBrand(string BrandId);
    }
}
