﻿using JeansAppAPI.Entities;
using JeansAppAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace JeansAppAPI.Repository
{
    public class CartRepository : ICartRepository
    {
        private readonly JeansStationDBContext _context;

        public CartRepository(JeansStationDBContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context)); // Initialize the database context
        }

        public async Task AddCartItem(CartItem cartitem)
        {
           
                await _context.CartItems.AddAsync(cartitem); // Add a new cart item to the database
                await _context.SaveChangesAsync(); // Save changes to the database
            
        }

        public async Task<List<CartItem>> GetAllCartItems()
        {
            try
            {
                return await _context.CartItems.ToListAsync(); // Retrieve all cart items from the database
            }
            catch (Exception ex)
            {
                // Handle exceptions that may occur during the retrieval operation
                throw new Exception(ex.Message);
            }
        }

        public async Task<List<CartItem>> GetCartitemById(string CartId)
        {
            try
            {
                return await _context.CartItems
                                     .Where(ci => ci.CartId == CartId)
                                     .ToListAsync();
            }
            catch (Exception ex)
            {
                // Handle exceptions that may occur during the retrieval operation
                throw new Exception(ex.Message);
            }
        }

        public async Task Update(CartItem cartitem)
        {
            try
            {
                _context.CartItems.Update(cartitem); // Update the cart item in the database
                await _context.SaveChangesAsync(); // Save changes to the database
            }
            catch (Exception ex)
            {
                // Handle exceptions that may occur during the update operation
                throw new Exception(ex.Message);
            }
        }

        public async Task Delete(string CartId)
        {
            try
            {
                var cartItem = await _context.CartItems.FindAsync(CartId); // Find the cart item by its ID
               
                _context.CartItems.Remove(cartItem); // Remove the cart item from the database
                await _context.SaveChangesAsync(); // Save changes to the database
            }
            catch (Exception ex)
            {
                // Handle exceptions that may occur during the delete operation
                throw new Exception(ex.Message);
            }
        }



        public async Task<List<CartItem>> GetCartItemsByUserId(string UserId)
        {
            try
            {
                return await _context.CartItems
                                     .Where(ci => ci.UserId == UserId)
                                     .ToListAsync(); // Retrieve all cart items for the specified user
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public async Task<List<CartDTO>> GetCartDTOItemsByUserId(string UserId)
        {
            return await _context.CartItems
        .Where(c => c.UserId == UserId)
        .Include(c => c.Product) // Include related Product data
        .Select(c => new CartDTO
        {
            CartId=c.CartId,
            ProductId  =c.Product.ProductId,
            ProductName = c.Product.ProductName,
            Size=c.Product.Size,
           Discount=c.Product.Discount,
            Price = c.Product.Price,
            Quantity = c.Quantity,

            TotalPrice = (c.Product.Price - (c.Product.Price * c.Product.Discount)) * c.Quantity
        })
        .ToListAsync();


           
        }
        public async Task ClearCartAsync(string userId)
        {
            try
            {
                // Retrieve all cart items for the user
                var cartItems = _context.CartItems.Where(c => c.UserId == userId);

                if (cartItems != null && cartItems.Any())
                {
                    // Remove the cart items
                    _context.CartItems.RemoveRange(cartItems);

                    // Save changes to the database
                    await _context.SaveChangesAsync();
                }
            }
            catch (Exception ex)
            {
                // Log the exception if needed and rethrow or handle the exception
                throw new Exception("Error clearing cart", ex);
            }
        }
    }
}


