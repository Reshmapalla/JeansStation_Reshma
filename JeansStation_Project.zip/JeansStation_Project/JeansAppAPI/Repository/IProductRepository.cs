﻿using JeansAppAPI.Entities;
using JeansAppAPI.Models;

namespace JeansAppAPI.Repository
{
        public interface IProductRepository
        {
            // Adds a new product to the repository asynchronously
            Task AddProduct(Product product);

            // Retrieves a list of all products from the repository asynchronously
            Task<List<Product>> GetAllProducts();

            // Retrieves a specific product by its ProductId asynchronously
            Task<Product> GetProductById(string ProductId);


            // Updates an existing product in the repository asynchronously
            Task Update(Product product);

            // Deletes a product from the repository by its ProductId asynchronously
            Task Delete(string ProductId);

        Task<Product> GetProductByName(string Name);//Get a product by its name

        Task<IEnumerable<ProductDTO>> UserGetAllProductsAsync();


        Task<IEnumerable<Product>> FilterProductsAsync(double? minPrice, double? maxPrice, string color, string brandName, string size, string categoryName);
        





    }
}


