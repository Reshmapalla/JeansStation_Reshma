﻿using JeansAppAPI.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace JeansAppAPI.Repository
{
    public class BrandRepository:IBrandRepository
    {

        
            private readonly JeansStationDBContext _context;
            // Constructor to inject the DbContext dependency
            public BrandRepository(JeansStationDBContext context)
            {
                // Check if the provided context argument is null.
                // If it is null, throw an ArgumentNullException with the parameter name 'context'.
                // This ensures that the controller cannot be instantiated without a valid repository.
                _context = context ?? throw new ArgumentNullException(nameof(context));

            }


            public async Task<List<Brand>> GetAllBrands()
            {
                try
                {
                    // Retrieve all Brands from the database
                    return await _context.Brands.ToListAsync();
                }
                catch (Exception ex)
                {
                    // Handle any errors that occur during the retrieval
                    throw new Exception(ex.Message);
                }
            }


            public async Task<Brand> GetBrandById(string id)
            {
                try
                {
                    // Attempt to find the Brand by its ID
                    var brand = await _context.Brands.FindAsync(id);

                    // Check if the Brand was found
                    if (brand == null)
                    {
                        throw new KeyNotFoundException($"Brand with ID '{id}' not found.");
                    }

                    // Return the found Brand
                    return brand;
                }
                catch (Exception ex)
                {
                    // Handle any errors that occur during the retrieval
                    throw new Exception("An error occurred while retrieving the Brand.", ex);
                }
            }



            public async Task DeleteBrand(string id)
            {
                try
                {
                    // Attempt to find the Brand by its ID
                    var brand = await _context.Brands.FindAsync(id);

                    // Check if the Brand was found
                    if (brand == null)
                    {
                        throw new KeyNotFoundException($"Brand with ID '{id}' not found.");
                    }

                    // Remove the Brand from the database
                    _context.Brands.Remove(brand);

                    // Save the changes to the database
                    await _context.SaveChangesAsync();
                }
                catch (Exception ex)
                {
                    // Handle any errors that occur during the deletion
                    throw new Exception("An error occurred while deleting the Brand.", ex);
                }
            }



            public async Task UpdateBrand(Brand brand)
            {
                if (brand == null)
                {
                    // Handle the case where the Brand is null
                    throw new ArgumentNullException(nameof(brand), "Brand cannot be null.");
                }

                try
                {
                    // Update the Brand in the database
                    _context.Brands.Update(brand);

                    // Save the changes to the database
                    await _context.SaveChangesAsync();
                }
                catch (Exception ex)
                {
                    // Handle any errors that occur during the update
                    throw new Exception("An error occurred while updating the Brand.", ex);
                }
            }



            public async Task AddBrand(Brand brand)
            {


                    // Add the new Brand to the database
                    await _context.Brands.AddAsync(brand);

                    // Save the changes to the database
                    await _context.SaveChangesAsync();
              
            }

        public async Task<Brand> GetBrandByBrandName(string Name)
        {
            try
            {
                var brand = await _context.Brands.FirstOrDefaultAsync(x => x.BrandName == Name);
                return brand;
                
            }
            catch (Exception ex)
            {
                // Log the exception or handle it as needed
                Console.WriteLine("An error occurred while retrieving the product: " + ex.Message);
                throw;
            }
        }

       
    }
    }



