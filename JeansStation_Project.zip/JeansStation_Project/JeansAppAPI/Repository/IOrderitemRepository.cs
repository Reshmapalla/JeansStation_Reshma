﻿using JeansAppAPI.Entities;

namespace JeansAppAPI.Repository
{
    public interface IOrderitemRepository
    {
        Task<List<OrderItems>> GetAll();

        Task<OrderItems> GetOrderitemById(string OrderItemId);

        Task AddOrderItems(OrderItems orderItems);
        Task<List<OrderItems>> GetOrderItemsByOrderId(Guid OrderId); // New method to get OrderItems by OrderId
    }
}
