﻿using JeansAppAPI.Entities;
using JeansAppAPI.Models;

namespace JeansAppAPI.Repository
{
    public interface ICartRepository
    {
       
        Task AddCartItem(CartItem cartitem);

      
        Task<List<CartItem>> GetAllCartItems();

        Task<List<CartItem>> GetCartitemById(string CartId);

        Task<List<CartItem> >GetCartItemsByUserId(string UserId);

        Task<List<CartDTO>> GetCartDTOItemsByUserId(string UserId);

        Task Update(CartItem cartitem);

        
        Task Delete(string CartId);

        Task ClearCartAsync(string userId);
    }
}
