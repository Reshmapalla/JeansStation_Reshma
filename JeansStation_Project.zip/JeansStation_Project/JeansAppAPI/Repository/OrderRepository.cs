﻿using JeansAppAPI.Entities;
using JeansAppAPI.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JeansAppAPI.Repository
{
    public class OrderRepository : IOrderRepository
    {
        private readonly JeansStationDBContext _dbContext;

        public OrderRepository(JeansStationDBContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task Add(Order order)
        {
            try
            {
                await _dbContext.Orders.AddAsync(order); // Adds a new Order to the database asynchronously.
                await _dbContext.SaveChangesAsync(); // Saves changes to the database asynchronously.
            }
            catch (Exception ex)
            {
                // Log the exception (logging implementation not shown here)
                throw new Exception(ex.Message);
            }
        }

        public async Task Delete(Guid id)
        {
            try
            {

                var order = await _dbContext.Orders.FindAsync(id); // Finds the Order by its ID asynchronously.
                if (order != null)
                {
                    _dbContext.Orders.Remove(order); // Removes the Order from the database.
                    await _dbContext.SaveChangesAsync(); // Saves changes to the database asynchronously.
                }
                else
                {
                    throw new Exception("Order not found"); // Throws an exception if the Order is not found.
                }
            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message);
            }
        }

        public async Task<List<Order>> GetAllOrders()
        {
            try
            {
                return await _dbContext.Orders.ToListAsync(); // Retrieves all Orders from the database asynchronously.
            }
            catch (Exception ex)
            {
                // Log the exception (logging implementation not shown here)
                throw new Exception(ex.Message);
            }
        }

        public async Task<Order> GetOrderById(Guid orderId)
        {
            try
            {
                var order = await _dbContext.Orders.FindAsync(orderId); // Retrieves the Order by its ID asynchronously.
                return order;
            }
            catch (Exception ex)
            {
                // Log the exception (logging implementation not shown here)
                throw new Exception(ex.Message);
            }
        }

        public async Task Update(Order order)
        {
            try
            {
                _dbContext.Orders.Update(order); // Updates an existing Order in the database.
                await _dbContext.SaveChangesAsync(); // Saves changes to the database asynchronously.
            }
            catch (Exception ex)
            {
                // Log the exception (logging implementation not shown here)
                throw new Exception(ex.Message);
            }
        }

        public async Task<List<Order>> GetOrdersByCustomerId(string customerId)
        {
            try
            {
                return await _dbContext.Orders
                    .Where(o => o.UserId == customerId) // Filters orders by customer ID.
                    .ToListAsync(); // Retrieves the filtered orders asynchronously.
            }
            catch (Exception ex)
            {
                // Log the exception (logging implementation not shown here)
                throw new Exception(ex.Message);
            }
        }

        public async Task<List<Order>> GetOrdersByDateRange(DateTime startDate, DateTime endDate)
        {
            try
            {
                return await _dbContext.Orders
                    .Where(o => o.OrderDate >= startDate && o.OrderDate <= endDate) // Filters orders within the date range.
                    .ToListAsync(); // Retrieves the filtered orders asynchronously.
            }
            catch (Exception ex)
            {
                // Log the exception (logging implementation not shown here)
                throw new Exception(ex.Message);
            }
        }




        public async Task<IEnumerable<OrderDTO>> GetOrderDetails(string userId)
        {
            try
            {
                var orders = await (from order in _dbContext.Orders
                                    join transaction in _dbContext.Transactions on order.OrderId equals transaction.OrderId
                                    join orderItem in _dbContext.OrderItems on order.OrderId equals orderItem.OrderId
                                    join product in _dbContext.Products on orderItem.ProductId equals product.ProductId
                                    where order.UserId == userId
                                    select new
                                    {
                                        Order = order,
                                        Transaction = transaction,
                                        OrderItem = orderItem,
                                        Product = product
                                    })
                                    .GroupBy(x => new
                                    {
                                        x.Order.OrderId,
                                        x.Order.Address,
                                        x.Order.TotalPrice,
                                        x.Order.OrderStatus,
                                        x.Order.OrderDate,
                                        x.Order.DeliveryDate,
                                        x.Transaction.TransactionMethod,
                                        x.Transaction.TransactionStatus,
                                        x.Transaction.TransactionDate
                                    })
                                    .Select(g => new OrderDTO
                                    {
                                        OrderId = g.Key.OrderId,
                                        Address = g.Key.Address,
                                        TotalPrice = g.Key.TotalPrice,
                                        OrderStatus = g.Key.OrderStatus,
                                        OrderDate = g.Key.OrderDate,
                                        DeliveryDate = g.Key.DeliveryDate,
                                        TransactionMethod = g.Key.TransactionMethod,
                                        TransactionStatus = g.Key.TransactionStatus,
                                        TransactionDate = g.Key.TransactionDate,
                                        OrderItems = g.Select(x => new OrderItemDTO
                                        {
                                            ProductId = x.OrderItem.ProductId,
                                            ProductName = x.Product.ProductName,
                                            Quantity = x.OrderItem.Quantity,
                                            UnitPrice = x.OrderItem.UnitPrice,
                                            TotalPrice = x.OrderItem.TotalPrice
                                        }).ToList()
                                    }).ToListAsync();

                return orders;
            }
            catch (Exception ex)
            {
                // Log the exception (optional)
                throw new Exception("Error fetching orders.", ex);
            }
        }


        //public async Task<IEnumerable<OrderDTO>> GetOrderDetails(string userId)
        //{
        //    try
        //    {
        //        var orders = await (from order in _dbContext.Orders
        //                            join transaction in _dbContext.Transactions on order.OrderId equals transaction.OrderId
        //                            join orderItem in _dbContext.OrderItems on order.OrderId equals orderItem.OrderId
        //                            join product in _dbContext.Products on orderItem.ProductId equals product.ProductId
        //                            where order.UserId == userId
        //                            select new OrderDTO
        //                            {
        //                                OrderId = order.OrderId,
        //                                Address = order.Address,
        //                                TotalPrice = order.TotalPrice,
        //                                OrderStatus = order.OrderStatus,
        //                                OrderDate = order.OrderDate,
        //                                DeliveryDate = order.DeliveryDate,
        //                                TransactionMethod = transaction.TransactionMethod,
        //                                TransactionStatus = transaction.TransactionStatus,
        //                                TransactionDate = transaction.TransactionDate,
        //                                OrderItems = (from oi in _dbContext.OrderItems
        //                                              where oi.OrderId == order.OrderId
        //                                              select new OrderItemDTO
        //                                              {
        //                                                  ProductId = oi.ProductId,
        //                                                  ProductName = product.ProductName,
        //                                                  Quantity = oi.Quantity,
        //                                                  UnitPrice = oi.UnitPrice,
        //                                                  TotalPrice = oi.TotalPrice
        //                                              }).ToList()
        //                            }).ToListAsync();

        //        return orders;
        //    }
        //    catch (Exception ex)
        //    {
        //        // Log the exception (optional)
        //        throw new Exception("Error fetching orders.", ex);
        //    }
        //}





        public async Task<List<OrderDTO>> GetAllOrdersForAdminAsync()
        {
            var orders = await (from o in _dbContext.Orders
                                join t in _dbContext.Transactions on o.OrderId equals t.OrderId
                                join user in _dbContext.Users on o.UserId equals user.UserId // Join with Users table
                                select new OrderDTO
                                {
                                    OrderId = o.OrderId,
                                    Address = o.Address,
                                    TotalPrice = o.TotalPrice,
                                    OrderStatus = o.OrderStatus,
                                    OrderDate = o.OrderDate,
                                    DeliveryDate = o.DeliveryDate,

                                    // Transaction details
                                    TransactionMethod = t.TransactionMethod,
                                    TransactionStatus = t.TransactionStatus,
                                    TransactionDate = t.TransactionDate,
                                    //UserDetails
                                    UserId = user.UserId, // Include user ID
                                    UserName = user.Name, // Include user name

                                    // Order items
                                    OrderItems = (from oi in _dbContext.OrderItems
                                                  join p in _dbContext.Products on oi.ProductId equals p.ProductId
                                                  where oi.OrderId == o.OrderId
                                                  select new OrderItemDTO
                                                  {
                                                      ProductId = p.ProductId,
                                                      ProductName = p.ProductName,
                                                      Quantity = oi.Quantity,
                                                      UnitPrice = oi.UnitPrice,
                                                      TotalPrice = oi.TotalPrice
                                                  }).ToList()
                                }).ToListAsync();

            return orders;
        }

       

    }
}

