﻿using JeansAppAPI.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace JeansAppAPI.Repository
{
    public interface ICategoryRepository
    {
        
            // Retrieve all categories
            Task<List<Category>> GetAllCategories();

            // Retrieve a category by its ID
            Task<Category> GetCategoryById(string id);

        //retreive a ctegory by its Name
        Task<Category> GetCategoryByName(string name);

        // Delete a category by its ID
        Task DeleteCategory(string id);

            // Update an existing category
            Task UpdateCategory(Category category);

            // Add a new category
            Task AddCategory(Category category);
        

    }
}

