﻿using JeansAppAPI.Entities;
using JeansAppAPI.Models;
using Microsoft.CodeAnalysis;
using Microsoft.EntityFrameworkCore;

namespace JeansAppAPI.Repository
{
    public class ProductRepository:IProductRepository
    {
        private readonly JeansStationDBContext _dbContext;
        // Constructor to inject the DbContext dependency
        public ProductRepository(JeansStationDBContext dbContext)
        {
            _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
        }

        // Asynchronously adds a new product to the repository
        public async Task AddProduct(Product product)
        {
            try
            {
                await _dbContext.Products.AddAsync(product); // Add the product to the context
                await _dbContext.SaveChangesAsync(); // Save changes to the database
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred while registering the user: {ex.Message}");
            }
        }


        // Asynchronously deletes a product by its ProductId
        public async Task Delete(string ProductId)
        {
            try
            {
                var product = await _dbContext.Products.FirstOrDefaultAsync(x => x.ProductId == ProductId);
                if (product != null)
                {
                    _dbContext.Products.Remove(product);
                    await _dbContext.SaveChangesAsync();
                }
                else
                {
                    // Handle the case where the product is not found
                    Console.WriteLine("Product not found.");
                }
            }
            catch (Exception ex)
            {
                // Log the exception or handle it as needed
                Console.WriteLine("An error occurred while deleting the product: " + ex.Message);
                throw;
            }
        }


        // Asynchronously retrieves a list of all products
        public async Task<List<Product>> GetAllProducts()
        {
            try
            {
                return await _dbContext.Products.ToListAsync();
            }
            catch (Exception ex)
            {
                // Log the exception or handle it as needed
              throw new Exception(ex.Message);
            }
        }

        // Asynchronously retrieves a specific product by its ProductId
        public async Task<Product> GetProductById(string ProductId)
        {
            try
            {
                return await _dbContext.Products.FindAsync(ProductId);
            }
            catch (Exception ex)
            {
                // Log the exception or handle it as needed
                Console.WriteLine("An error occurred while retrieving the product: " + ex.Message);
                throw;
            }
        }

        public async Task<Product> GetProductByName(string ProductName)
        {
            try
            {
                var product=await _dbContext.Products.FirstOrDefaultAsync(x => x.ProductName == ProductName);
                return product;
            }
            catch (Exception ex)
            {
                // Log the exception or handle it as needed
                Console.WriteLine("An error occurred while retrieving the product: " + ex.Message);
                throw;
            }
        }

        // Asynchronously updates an existing product
        public async Task Update(Product product)
        {
            try
            {
                _dbContext.Products.Update(product);
                await _dbContext.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                // Log the exception or handle it as needed
                Console.WriteLine("An error occurred while updating the product: " + ex.Message);
                throw;
            }
        }
        public async Task<IEnumerable<Product>> FilterProductsAsync(
        double? minPrice, double? maxPrice,
        string color, string brandName,
        string size, 
        string categoryName)
        {
            var query = _dbContext.Products
                                .Include(p => p.Brand)
                                .Include(p => p.Category)
                                .AsQueryable();

            if (minPrice.HasValue)
            {
                query = query.Where(p => p.Price >= minPrice.Value);
            }

            if (maxPrice.HasValue)
            {
                query = query.Where(p => p.Price <= maxPrice.Value);
            }

            if (!string.IsNullOrEmpty(color))
            {
                query = query.Where(p => p.Color == color);
            }

            if (!string.IsNullOrEmpty(brandName))
            {
                query = query.Where(p => p.Brand.BrandName == brandName);
            }

            if (!string.IsNullOrEmpty(size))
            {
                query = query.Where(p => p.Size == size);
            }

            if (!string.IsNullOrEmpty(categoryName))
            {
                query = query.Where(p => p.Category.CategoryName == categoryName);
            }

            return await query.ToListAsync();
        }

        public async Task<IEnumerable<ProductDTO>> UserGetAllProductsAsync()
        {
            return await _dbContext.Products
            .Include(p => p.Brand)
            .Include(p => p.Category)
            .Select(p => new ProductDTO
            {
               ProductId=p.ProductId,
                ProductName = p.ProductName,
                Price = p.Price,
                BrandName = p.Brand.BrandName,
                CategoryName = p.Category.CategoryName,
                Color = p.Color,
                Size=p.Size,
                Discount=p.Discount,
              
            }) 
            .ToListAsync();
        }
    }
}
