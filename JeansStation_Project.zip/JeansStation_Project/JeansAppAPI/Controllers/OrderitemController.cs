﻿using JeansAppAPI.Entities;
using JeansAppAPI.Repository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;

namespace JeansAppAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderItemsController : ControllerBase
    {
        private readonly IOrderitemRepository _repository;

        public OrderItemsController(IOrderitemRepository repository)
        {
            _repository = repository;
        }
       // [Authorize(Roles = "Admin,Customer")]
        [HttpPost,Route("AddOrderItem")]
        public async Task<IActionResult> Add([FromBody] OrderItems orderItem)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    orderItem.OrderItemId = "OI" + new Random().Next(1000, 9999);
                    await _repository.AddOrderItems(orderItem);
                    return StatusCode(200, orderItem);
                }
                else
                {
                    return BadRequest("Enter Valid Details");
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An error occurred: {ex.Message}");
            }

            }
        [Authorize(Roles = "Admin,Customer")]
        [HttpGet, Route("GetAll")]
        public async Task<IActionResult> GetAll()
        {
            try
            {
                var orderItems = await _repository.GetAll(); // Retrieves all OrderItems asynchronously.
                return Ok(orderItems); // Returns the OrderItems with a 200 OK status.
            }
            catch (Exception ex)
            {
                // Log the exception (logging implementation not shown here)
                return StatusCode(500, $"An error occurred: {ex.Message}"); // Returns a 500 Internal Server Error with the exception message.
            }
        }
      // [Authorize(Roles = "Admin,Customer")]
        [HttpGet, Route("GetOrderitemById/{id}")]
        public async Task<IActionResult> GetOrderitemById([FromRoute] string id)
        {
            try
            {
                var orderItem = await _repository.GetOrderitemById(id); // Retrieves the OrderItem by ID asynchronously.
                if (orderItem != null)
                {
                    return Ok(orderItem); // Returns the OrderItem with a 200 OK status.
                }
                else
                {
                    return NotFound("Order item not found."); // Returns a 404 Not Found if the OrderItem is not found.
                }
            }
            catch (Exception ex)
            {
                // Log the exception (logging implementation not shown here)
                return StatusCode(500, $"An error occurred: {ex.Message}"); // Returns a 500 Internal Server Error with the exception message.
            }
        }
      // [Authorize(Roles = "Admin,Customer")]
        [HttpGet("byOrderId/{orderId}")]
        public async Task<IActionResult> GetOrderItemsByOrderId(Guid orderId)
        {
            try
            {
                var orderItems = await _repository.GetOrderItemsByOrderId(orderId);
                if (orderItems == null || orderItems.Count == 0)
                {
                    return NotFound(); // Return 404 Not Found if no order items are found for the given order ID
                }
                return Ok(orderItems); // Return 200 OK with the list of order items
            }
            catch (Exception ex)
            {
                // Log the exception (logging implementation not shown here)
                return StatusCode(500, ex.Message); // Return 500 Internal Server Error with exception message
            }
        }
    }
}
