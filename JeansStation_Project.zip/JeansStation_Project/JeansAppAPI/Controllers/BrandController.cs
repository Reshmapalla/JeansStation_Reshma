﻿using JeansAppAPI.Entities;
using JeansAppAPI.Repository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;

namespace JeansAppAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BrandController : Controller
    {
    
            private readonly IBrandRepository _brandRepository ;

            public BrandController(IBrandRepository brandRepository)
            {
            // Ensure that the categoryRepository is not null
            _brandRepository = brandRepository ?? throw new ArgumentNullException(nameof(brandRepository));
            }

            [Authorize(Roles = "Admin,Customer")]
            [HttpGet("GetAllBrands")]
            public async Task<IActionResult> GetAll()
            {
                try
                {
                    // Retrieve all categories using the repository
                    var brands = await _brandRepository.GetAllBrands();

                    // Return the categories with an OK status
                    return Ok(brands);
                }
                catch (Exception ex)
                {
                    // Log the exception (logging not implemented here)
                    return StatusCode(500, "An error occurred while retrieving brands.");
                }
            }


          [Authorize(Roles = "Admin,Customer")]
            [HttpGet("GetBrandById/{id}")]
            public async Task<IActionResult> Get([FromRoute] string id)
            {
                try
                {
                    // Attempt to retrieve the Brand by its ID
                    var brand = await _brandRepository.GetBrandById(id);

                    // If the category exists, return it with an OK status
                    if (brand != null)
                    {
                        return Ok(brand);
                    }

                    // Return a NotFound status if the Brand doesn't exist
                    return NotFound($"Brand with ID '{id}' not found.");
                }
                catch (Exception ex)
                {
                    // Log the exception (logging not implemented here)
                    return StatusCode(500, "An error occurred while retrieving the Brand.");
                }
            }


           [Authorize(Roles = "Admin")]
            [HttpPost("AddBrand")]
            public async Task<IActionResult> Add([FromBody] Brand brand)
            {


                 if (ModelState.IsValid)
                    {
                brand.BrandId = "B" + new Random().Next(1000, 9999);
                await _brandRepository.AddBrand(brand);
                        return StatusCode(200, brand);
                    }
                    else
                    {
                        return BadRequest("Enter Valid Details!!");
                    }
               
            }


            [Authorize(Roles = "Admin")]
            [HttpPut("EditBrand")]
            public async Task<IActionResult> Edit([FromBody] Brand brand)
            {
                if (brand == null)
                {
                    // Return a BadRequest status if the category is null
                    return BadRequest("Category cannot be null.");
                }

                try
                {
                    // Update the category using the repository
                    await _brandRepository.UpdateBrand(brand);

                    // Return an OK status with the updated category
                    return Ok(brand);
                }
                catch (Exception ex)
                {
                    // Log the exception (logging not implemented here)
                    return StatusCode(500, "An error occurred while updating the Brand.");
                }
            }

           [Authorize(Roles = "Admin")]

            [HttpDelete("DeleteBrand")]
            public async Task<IActionResult> Delete([FromQuery] string id)
            {


                try
                {
                    // Attempt to delete the category by its ID
                    await _brandRepository.DeleteBrand(id);
                    //return deleted Category ````````````Id
                    return Ok(id);
                }
                catch (Exception ex)
                {
                    // Log the exception (logging not implemented here)
                    return StatusCode(500, "An error occurred while deleting the category.");
                }
            }
           [Authorize(Roles = "Admin,Customer")]
            [HttpGet("GetCategoryByName/{categoryName}")]
            public async Task<IActionResult> GetcategoryByName([FromQuery] string brandName)
            {
                try
                {
                    var category = await _brandRepository.GetBrandByBrandName(brandName);
                    if (category != null)
                    {
                        return Ok(category);
                    }
                    return NotFound($"Category with Name '{brandName}' not found.");
                }
                catch (Exception ex)
                {

                    return StatusCode(500, "An error occurred while deleting the category.");
                }

            }
        }
    }


