﻿using JeansAppAPI.Entities;
using JeansAppAPI.Repository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace JeansAppAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CartController : ControllerBase
    {
        private readonly ICartRepository _cartRepository;

        public CartController(ICartRepository cartRepository)
        {
            _cartRepository = cartRepository ?? throw new ArgumentNullException(nameof(cartRepository)); // Initialize the repository
        }

        [Authorize(Roles = "Admin,Customer")]
        [HttpGet, Route("GetAllCartItems")]
        public async Task<IActionResult> GetAll()
        {
            try
            {
                var userId = User.Identity.Name;
                var cartItems = await _cartRepository.GetAllCartItems(); // Retrieve all cart items
                return Ok(cartItems); // Return 200 OK with cart items
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        [Authorize(Roles = "Admin,Customer")]
        [HttpGet, Route("GetCartItemById/{id}")]
        public async Task<IActionResult> Get([FromRoute] string id)
        {
            try
            {
                var cartItem = await _cartRepository.GetCartitemById(id); // Retrieve a specific cart item by ID
                return Ok(cartItem); // Return 200 OK with the cart item
            }
           
            catch (Exception ex)
            {
                throw;
            }
        }

        [Authorize(Roles = "Customer")]
        [HttpPost, Route("AddCartItem")]
        public async Task<IActionResult> Add([FromBody] CartItem cartItem)
        {
           
                //cartItem.UserId = User.Identity.Name;
                cartItem.CartId = "Ct" + new Random().Next(1000, 9999);
                await _cartRepository.AddCartItem(cartItem); // Add a new cart item
                return CreatedAtAction(nameof(Get), new { id = cartItem.CartId }, cartItem); // Return 201 Created with the cart item
           
        }
        [Authorize(Roles = "Customer")]
        [HttpPut, Route("UpdateCartItem")]

        public async Task<IActionResult> Update([FromBody] CartItem cartItem)
        {
            try
            {
                await _cartRepository.Update(cartItem); // Update an existing cart item
                return Ok(cartItem); // Return 200 OK with the updated cart item
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}"); // Handle exceptions
            }
        }
        [Authorize(Roles = "Customer")]
        [HttpDelete, Route("DeleteCartItem")]
        public async Task<IActionResult> Delete([FromQuery] string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                return BadRequest("Cart item ID cannot be null or empty"); // Return 400 Bad Request if ID is invalid
            }

            try
            {
                var cartItem = await _cartRepository.GetCartitemById(id);
                if (cartItem == null)
                {
                    return NotFound("Cart item not found"); // Return 404 if the cart item doesn't exist
                }

                await _cartRepository.Delete(id); // Delete the cart item by ID
                return Ok("Cart item deleted successfully"); // Return 200 OK if deletion is successful
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}"); // Handle exceptions
            }
        }
        [Authorize(Roles = "Admin,Customer")]
        [HttpGet, Route("GetCartItemsByUserId/{userId}")]
        public async Task<IActionResult> GetCartItemsByUserId([FromRoute] string userId)
        {
            try
            {
                var cartItems = await _cartRepository.GetCartItemsByUserId(userId); // Retrieve all cart items for the specified user
                return Ok(cartItems); // Return 200 OK with the cart items
            }
            catch (Exception ex)
            {
                // Handle exceptions that may occur during the retrieval operation
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
        [Authorize(Roles = "Admin,Customer")]
        [HttpGet, Route("GetCartItemsDTOByUserId/{userId}")]
        public async Task<IActionResult> GetCartItemsDTOByUserId([FromRoute] string userId)
        {
            try
            {
                var cartItems = await _cartRepository.GetCartDTOItemsByUserId(userId); // Retrieve all cart items for the specified user
                return Ok(cartItems); // Return 200 OK with the cart items
            }
            catch (Exception ex)
            {
                // Handle exceptions that may occur during the retrieval operation
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
        [Authorize(Roles = "Admin,Customer")]
        [HttpDelete("ClearCart/{userId}")]
        public async Task<IActionResult> ClearCart(string userId)
        {
            try
            {
                await _cartRepository.ClearCartAsync(userId);
                return Ok(new { message = "Cart cleared successfully." });
            }
            catch (Exception ex)
            {
                // Return error if clearing the cart fails
                return StatusCode(500, new { message = ex.Message });
            }
        }
    }
}

