import React, { useEffect, useState } from 'react';
import axios from 'axios';
import "bootstrap/dist/css/bootstrap.min.css";
import "./OrderDetails.css";

const OrderDetails = () => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  // Retrieve user ID from session storage
  const userId = sessionStorage.getItem('userId'); // or localStorage.getItem('userId')

  useEffect(() => {
    const fetchOrders = async () => {
      if (userId) {
        try {
          const response = await axios.get(`http://localhost:5089/api/Order/OrderDetails?userId=${userId}`,{
            headers: {
              Authorization: `Bearer ${sessionStorage.getItem("token")}`,
            }
          });
          setOrders(response.data);
          setLoading(false);
        } catch (error) {
          console.error("Error fetching order details", error);
          setLoading(false);
        }
      } else {
        console.error("No userId found in session data");
        setLoading(false);
      }
    };

    fetchOrders();
  }, [userId]);

  const deleteOrder = async (orderId) => {
    try {
      await axios.delete(`http://localhost:5089/api/Order/DeleteOrder?id=${orderId}`, {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        },
      });
      // Update the orders list after deletion
      setOrders(orders.filter(order => order.orderId !== orderId));
    } catch (error) {
      console.error("Error deleting order:", error.response?.data || error);
      alert("Failed to delete order.");
    }
  };

  if (loading) {
    return <p>Loading order details...</p>;
  }

  return (
    <div className="container">
      <h2>Your Orders</h2>
      {orders.length === 0 ? (
        <p>No orders found for this user.</p>
      ) : (
        <div className="order-list">
          {orders.map(order => (
            <div key={order.orderId} className="card mb-4">
              <div className="card-header">
                <h5>Order #{order.orderId} - Rs{order.totalPrice.toFixed(2)}</h5>
                <p>Order Date: {new Date(order.orderDate).toLocaleDateString()}</p>
                <button
                  onClick={() => deleteOrder(order.orderId)}
                  className="btn btn-danger btn-sm"
                >
                  Delete Order
                </button>
              </div>

              <div className="card-body">
                <div className="row">
                  {/* Order Information */}
                  <div className="col-md-6">
                    <h6>Order Information</h6>
                    <p><strong>Address:</strong> {order.address}</p>
                    <p><strong>Status:</strong> {order.orderStatus}</p>
                    <p><strong>Delivery Date:</strong> {new Date(order.deliveryDate).toLocaleDateString()}</p>
                  </div>

                  {/* Transaction Details */}
                  <div className="col-md-6">
                    <h6>Transaction Details</h6>
                    <p><strong>Method:</strong> {order.transactionMethod}</p>
                    <p><strong>Status:</strong> {order.transactionStatus}</p>
                    <p><strong>Date:</strong> {new Date(order.transactionDate).toLocaleDateString()}</p>
                  </div>
                </div>

                {/* Order Items Table */}
                <h6>Order Items</h6>
                <table className="table table-sm table-bordered">
                  <thead>
                    <tr>
                      <th>Product ID</th>
                      <th>Product Name</th>
                      <th>Quantity</th>
                      <th>Unit Price</th>
                      <th>Total Price</th>
                    </tr>
                  </thead>
                  <tbody>
                    {order.orderItems.map((item) => (
                      <tr key={item.productId}>
                        <td>{item.productId}</td>
                        <td>{item.productName}</td>
                        <td>{item.quantity}</td>
                        <td>Rs.{item.unitPrice.toFixed(2)}</td>
                        <td>Rs.{item.totalPrice.toFixed(2)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default OrderDetails;




// import React, { useEffect, useState } from 'react';
// import axios from 'axios';
// import "bootstrap/dist/css/bootstrap.min.css";
// import "./OrderDetails.css";

// const OrderDetails = () => {
//   const [orders, setOrders] = useState([]);
//   const [loading, setLoading] = useState(true);

//   // Retrieve user ID from session storage
//   const userId = sessionStorage.getItem('userId'); // or localStorage.getItem('userId')

//   useEffect(() => {
//     const fetchOrders = async () => {
//       if (userId) {
//         try {
//           const response = await axios.get(`http://localhost:5089/api/Order/OrderDetails?userId=${userId}`);
//           setOrders(response.data);
//           setLoading(false);
//         } catch (error) {
//           console.error("Error fetching order details", error);
//           setLoading(false);
//         }
//       } else {
//         console.error("No userId found in session data");
//         setLoading(false);
//       }
//     };

//     fetchOrders();
//   }, [userId]);

//   if (loading) {
//     return <p>Loading order details...</p>;
//   }

//   return (
//     <div className="container">
//       <h2>Your Orders</h2>
//       {orders.length === 0 ? (
//         <p>No orders found for this user.</p>
//       ) : (
//         <div className="order-list">
//           {orders.map(order => (
//             <div key={order.orderId} className="card mb-4">
//               <div className="card-header">
//                 <h5>Order #{order.orderId} - ${order.totalPrice.toFixed(2)}</h5>
//                 <p>Order Date: {new Date(order.orderDate).toLocaleDateString()}</p>
//               </div>

//               <div className="card-body">
//                 <div className="row">
//                   {/* Order Information */}
//                   <div className="col-md-6">
//                     <h6>Order Information</h6>
//                     <p><strong>Address:</strong> {order.address}</p>
//                     <p><strong>Status:</strong> {order.orderStatus}</p>
//                     <p><strong>Delivery Date:</strong> {new Date(order.deliveryDate).toLocaleDateString()}</p>
//                   </div>

//                   {/* Transaction Details */}
//                   <div className="col-md-6">
//                     <h6>Transaction Details</h6>
//                     <p><strong>Method:</strong> {order.transactionMethod}</p>
//                     <p><strong>Status:</strong> {order.transactionStatus}</p>
//                     <p><strong>Date:</strong> {new Date(order.transactionDate).toLocaleDateString()}</p>
//                   </div>
//                 </div>

//                 {/* Order Items Table */}
//                 <h6>Order Items</h6>
//                 <table className="table table-sm table-bordered">
//                   <thead>
//                     <tr>
//                     <th>Product ID</th>
//                       <th>Product Name</th>
//                       <th>Quantity</th>
//                       <th>Unit Price</th>
//                       <th>Total Price</th>
//                     </tr>
//                   </thead>
//                   <tbody>
//                     {order.orderItems.map((item) => (
//                       <tr key={item.productId}>
//                         <td>{item.productId}</td>
//                         <td>{item.productName}</td>
//                         <td>{item.quantity}</td>
//                         <td>${item.unitPrice.toFixed(2)}</td>
//                         <td>${item.totalPrice.toFixed(2)}</td>
//                       </tr>
//                     ))}
//                   </tbody>
//                 </table>
//               </div>
//             </div>
//           ))}
//         </div>
//       )}
//     </div>
//   );
// };

// export default OrderDetails;

