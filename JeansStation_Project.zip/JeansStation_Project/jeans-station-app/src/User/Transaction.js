
import axios from "axios";
import { useRef } from "react";
import "./Transaction.css"; // Import your CSS file

const Transaction = () => {
  const payMode = useRef();

  const transactionHandler = (e) => {
    e.preventDefault(); // Prevent page refresh on form submit

    let transactionData = {
      orderId: sessionStorage.getItem("orderId"),
      userId: sessionStorage.getItem("userId"), // Assuming the userId is stored in session
      transactionMethod: payMode.current.value, // The selected payment mode
      transactionStatus: "Processing", // You can set a default status or let backend handle it
      transactionDate: new Date(), // ISO format date
    };

    console.log("Transaction Data:", transactionData);

    axios
      .post("http://localhost:5089/api/Transaction/AddTransaction", transactionData,{
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        }
      })
      .then((response) => {
        console.log("Transaction success:", response.data);
        alert("Transaction successful!");
        // Handle success further if needed
      })
      .catch((error) => {
        console.error("Error processing transaction:", error);
        alert("Transaction failed.");
      });
  };

  return (
    <div className="transaction-container">
      <form className="transaction-form" onSubmit={transactionHandler}>
        <table>
          <tbody>
            <tr>
              <td colSpan={2}>Order ID: {sessionStorage.getItem("orderId")}</td>
            </tr>
            <tr>
              <td>Transaction Amount: Rs{sessionStorage.getItem("totalPrice")}</td>
            </tr>
            <tr>
              <td>Mode</td>
              <td>
                <select ref={payMode}>
                  <option>Debit</option>
                  <option>Credit</option>
                  <option>UPI</option>
                  <option>Cash On Delivery</option>
                </select>
              </td>
            </tr>
            <tr>
              <td colSpan={2}>
                <button type="submit">Make Transaction</button>
              </td>
            </tr>
          </tbody>
        </table>
      </form>
    </div>
  );
};

export default Transaction;













// import axios from "axios";
// import { useRef } from "react";
// import "./Transaction.css"


// const Transaction = () => {
//   const payMode = useRef();
//   const transactionHandler = (e) => {
//     e.preventDefault(); // Prevent page refresh on form submit

//     let transactionData = {
     
//       orderId: sessionStorage.getItem("orderId"),
//       userId: sessionStorage.getItem("userId"), // Assuming the userId is stored in session
//       transactionMethod: payMode.current.value, // The selected payment mode
//       transactionStatus: "Processing", // You can set a default status or let backend handle it
//       transactionDate: new Date(), // ISO format date
//     };

//     console.log("Transaction Data:", transactionData);

//     axios
//       .post("http://localhost:5089/api/Transaction/AddTransaction", transactionData)
//       .then((response) => {
//         console.log("Transaction success:", response.data);
//         alert("Transaction successful!");
//         // Handle success further if needed
//       })
//       .catch((error) => {
//         console.error("Error processing transaction:", error);
//         alert("Transaction failed.");
//       });
//   };

//   return (
//     <div className="container">
//       <form onSubmit={transactionHandler}>
//         <table className="table">
//           <tbody>
//             <tr>
//               <td colSpan={2}>Order ID: {sessionStorage.getItem("orderId")}</td>
//             </tr>
      
//             <tr>
//             <td>Transaction Amount: {sessionStorage.getItem("totalPrice")}</td>
//             </tr>
//             <tr>
//               <td>Mode</td>
//               <td>
//                 <select ref={payMode}>
//                   <option>Debit</option>
//                   <option>Credit</option>
//                   <option>UPI</option>
//                 </select>
//               </td>
//             </tr>
//             <tr>
//               <td colSpan={2}>
//                 <button type="submit">Make Transaction</button>
//               </td>
//             </tr>
//           </tbody>
//         </table>
//       </form>
//     </div>
//   );
// };

// export default Transaction;


