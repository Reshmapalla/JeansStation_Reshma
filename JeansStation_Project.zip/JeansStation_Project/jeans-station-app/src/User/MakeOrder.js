import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const MakeOrder = ({ cartItems, totalPrice, onOrderSuccess }) => {
  const navigate = useNavigate();
  const userId = sessionStorage.getItem("userId"); // Get userId from session
  const [address, setAddress] = useState(""); // State for storing user's address

  const storedQuantity = (cartId, fallbackQuantity) => {
    const quantity = sessionStorage.getItem(`cartQuantity_${cartId}`);
    if (quantity && !isNaN(quantity) && parseInt(quantity) > 0) {
      return parseInt(quantity);
    } else if (fallbackQuantity > 0) {
      return fallbackQuantity; // Use fallback if session storage fails
    } else {
      console.error(`Invalid quantity for cartId ${cartId}`);
      return null; // Return null or handle invalid case explicitly
    }
  };

  const makeOrder = () => {
    if (!address) {
      alert("Please enter your address before proceeding.");
      return;
    }

    const orderDate = new Date();
    const deliveryDate = new Date(orderDate);
    deliveryDate.setDate(orderDate.getDate() + 7); // Add 7 days

    const orderDateString = orderDate.toISOString();
    const deliveryDateString = deliveryDate.toISOString();

    const order = {
      userId: userId,
      totalPrice: totalPrice, // total price from props
      address: address, // Use the address input by the user
      orderStatus: "Processing",
      orderDate: orderDateString,
      deliveryDate: deliveryDateString,
    };

    sessionStorage.setItem("totalPrice", totalPrice);

    axios
      .post("http://localhost:5089/api/Order/AddOrder", order, {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        },
      })
      .then((response) => {
        console.log("Order created:", response.data);
        const orderId = response.data.orderId;
        sessionStorage.setItem("orderId", response.data.orderId);

        for (let item of cartItems) {
          AddOrderItem(item, orderId);
        }

        // Call the onOrderSuccess callback to clear the cart after the order is made
        onOrderSuccess();

        navigate("/user-layout/transaction");
      })
      .catch((error) => {
        console.error("Error creating order:", error.response?.data || error);
        alert("Failed to create order.");
      });
  };

  const AddOrderItem = (item, orderId) => {
    const quantity = storedQuantity(item.cartId, item.quantity); // Get the correct quantity from session storage
    if (quantity === null) {
      console.error(`No valid quantity found for cartId ${item.cartId}`);
      return; // Skip adding this item
    }

    const orderitem = {
      orderItemId: "",
      orderId: orderId,
      productId: item.productId, // Set product ID from the cart item
      unitPrice: item.price, // Set unit price from the cart item
      quantity: quantity, // Ensure quantity is an integer
      totalPrice: item.price * quantity, // Calculate total price based on quantity
    };

    axios
      .post("http://localhost:5089/api/OrderItems/AddOrderItem", orderitem, {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        },
      })
      .then((response) => {
        console.log("Order item created:", response.data);
      })
      .catch((error) => {
        console.error("Error adding order item:", error.response?.data || error);
      });
  };

  return (
    <div>
      <div className="form-group">
        <label htmlFor="address">Shipping Address</label>
        <input
          type="text"
          id="address"
          value={address}
          onChange={(e) => setAddress(e.target.value)} // Update state on input change
          className="form-control"
          placeholder="Enter your shipping address"
          required
        />
      </div>
      <button onClick={makeOrder} className="btn btn-primary">
        Confirm and Make Order
      </button>
    </div>
  );
};

export default MakeOrder;







// import React from "react";
// import axios from "axios";
// import { useNavigate } from "react-router-dom";

// const MakeOrder = ({ cartItems, totalPrice, onOrderSuccess }) => { // Added onOrderSuccess prop
//   const navigate = useNavigate();
//   const userId = sessionStorage.getItem("userId"); // Get userId from session

//   const storedQuantity = (cartId,fallbackQuantity) => {
//     const quantity = sessionStorage.getItem(`cartQuantity_${cartId}`);
//     if (quantity && !isNaN(quantity) && parseInt(quantity) > 0) {
//       return parseInt(quantity);
//     } 
//     else if (fallbackQuantity > 0) {
//       return fallbackQuantity; // Use fallback if session storage fails
//     }else {
//       console.error(`Invalid quantity for cartId ${cartId}`);
//       return null; // Return null or handle invalid case explicitly
//     }
//   };

//   const makeOrder = () => {
//     const orderDate = new Date();
//     const deliveryDate = new Date(orderDate);
//     deliveryDate.setDate(orderDate.getDate() + 7); // Add 7 days

//   console.log("Order Date (before formatting):", orderDate);
//   console.log("Delivery Date (before formatting):", deliveryDate); // Log the calculated delivery date

//   const orderDateString = orderDate.toISOString();
//   const deliveryDateString = deliveryDate.toISOString();

//   console.log("Order Date (ISO):", orderDateString);
//   console.log("Delivery Date (ISO):", deliveryDateString); // Log the ISO string to ensure correct calculation

//     const order = {
//       userId: userId,
//       totalPrice: totalPrice, // total price from props
//       address: "Srikakulam",
//       orderStatus: "Processing",
//       orderDate: orderDateString,
//       deliveryDate: deliveryDateString,
//     };

//     sessionStorage.setItem("totalPrice", totalPrice);

//     axios
//       .post("http://localhost:5089/api/Order/AddOrder", order, {
//         headers: {
//           Authorization: `Bearer ${sessionStorage.getItem("token")}`,
//         },
//       })
//       .then((response) => {
//         console.log("Order created:", response.data);
//         const orderId = response.data.orderId;
//         sessionStorage.setItem("orderId",response.data.orderId)
//         for (let item of cartItems) {
//           AddOrderItem(item, orderId);
//         }

//         // Call the onOrderSuccess callback to clear the cart after the order is made
//         onOrderSuccess();

//         navigate("/user-layout/transaction");
//       })
//       .catch((error) => {
//         console.error("Error creating order:", error.response?.data || error);
//         alert("Failed to create order.");
//       });
//   };

//   const AddOrderItem = (item, orderId) => {
//     const quantity = storedQuantity(item.cartId,item.quantity); // Get the correct quantity from session storage
//     if (quantity === null) {
//       console.error(`No valid quantity found for cartId ${item.cartId}`);
//       return; // Skip adding this item
//     }

//     const orderitem = {
//       orderItemId:"",
//       orderId: orderId,
//       productId: item.productId, // Set product ID from the cart item
//       unitPrice: item.price, // Set unit price from the cart item
//       quantity: quantity, // Ensure quantity is an integer
//       totalPrice: item.price * quantity, // Calculate total price based on quantity
//     };

//     axios
//       .post("http://localhost:5089/api/OrderItems/AddOrderItem", orderitem, {
//         headers: {
//           Authorization: `Bearer ${sessionStorage.getItem("token")}`,
//         },
//       })
//       .then((response) => {
//         console.log("OrderITEM created:", response.data);
//       })
//       .catch((error) => {
//         console.error("Error adding order item:", error.response?.data || error);
//       });
//   };

//   return (
//     <div>
//       <button onClick={makeOrder} className="btn btn-primary">
//         Confirm and Make Order
//       </button>
//     </div>
//   );
// };

// export default MakeOrder;




