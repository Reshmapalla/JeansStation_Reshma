import React, { useEffect } from "react";
import { Link, Outlet } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import './UserLayout.css'; // Import your CSS file

const User = () => {
  const navigate = useNavigate();
  useEffect(() => {
    if (sessionStorage.getItem("token") === null) {
      navigate("/login");
    }
  }, [navigate]);

  return (
    <div className="user-dashboard d-flex flex-column min-vh-100">
      <header className="header bg-dark text-white py-3 shadow-sm">
        <div className="container">
          <div className="d-flex justify-content-between align-items-center">
            <h1 className="header-title">User Dashboard</h1>
            <h2 className="header-subtitle">Logged in as: {sessionStorage.getItem("userId")}</h2>
            <nav>
              <ul className="navbar-nav d-flex flex-row">
                <li className="nav-item mx-2">
                  <Link className="nav-link text-white nav-link-hover" to="/home">
                    Home
                  </Link>
                </li>
                <li className="nav-item mx-2">
                <Link className="nav-link text-white nav-link-hover" to="user-dashboard">
                 View Products
                </Link>
                </li>
                <li className="nav-item mx-2">
                  <Link className="nav-link text-white nav-link-hover" to="cart">
                    View Cart
                  </Link>
                </li>
               
                <li className="nav-item mx-2">
                  <Link className="nav-link text-white nav-link-hover" to="orderdetails">
                    Orders
                  </Link>
                </li>
                <li className="nav-item mx-2">
                  <Link className="nav-link text-white nav-link-hover" to="/login">
                    Log Out
                  </Link>
                </li>
                <li className="nav-item mx-2">
                  <Link className="nav-link text-white nav-link-hover" to="profile">
                    Profile
                  </Link>
                </li>
              </ul>
            </nav>
          </div>
        </div>
      </header>

      <main className="flex-grow-1">
        <Outlet />
      </main>

      <footer className="footer bg-dark text-white text-center py-3 mt-auto">
        <div className="container">
          <p>&copy; 2024 ShopEase. All rights reserved.</p>
          <p>
            <Link to="/about" className="text-white text-decoration-none footer-link">
              About Us
            </Link>{" "}
            |{" "}
            <Link to="/contact" className="text-white text-decoration-none footer-link">
              Contact
            </Link>{" "}
            |{" "}
            <Link to="/help" className="text-white text-decoration-none footer-link">
              Help
            </Link>{" "}
            |{" "}
            <Link to="/mailus" className="text-white text-decoration-none footer-link">
              Mail Us
            </Link>
          </p>
        </div>
      </footer>
    </div>
  );
};

export default User;