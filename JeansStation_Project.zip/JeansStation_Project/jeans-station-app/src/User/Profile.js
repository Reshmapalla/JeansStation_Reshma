import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import "./Profile.css";

const Profile = () => {
    const [user, setUser] = useState({
        userId: "",
        name: "",
        email: "",
        password: "",
        role: "",
        mobile: ""
    });
    const [error, setError] = useState("");
    const [success, setSuccess] = useState("");
    const navigate = useNavigate();

    useEffect(() => {
        const userId = sessionStorage.getItem("userId");
        axios
            .get(`http://localhost:5089/api/Authenticate/GetUserById?id=${userId}`,{
                headers: {
                  Authorization: `Bearer ${sessionStorage.getItem("token")}`,
                }
              })
            .then((res) => {
                if (res.status === 200) setUser(res.data);
                else setError("Error fetching profile data");
            })
            .catch((err) => {
                setError("Error fetching profile data");
            });
    }, []);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setUser({ ...user, [name]: value });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        axios
            .put("http://localhost:5089/api/Authenticate/EditUser", user)
            .then((res) => {
                if (res.status === 200) {
                    setSuccess("Profile updated successfully");
                    setError("");
                    navigate("/home");
                } else {
                    setError("Error updating profile");
                }
            })
            .catch((err) => {
                setError("Error updating profile");
            });
    };

    return (
        <div className="edit-profile-container">
            <h2>Edit Your Profile</h2>
            <form onSubmit={handleSubmit} className="edit-profile-form">
                <div className="form-group">
                    <label htmlFor="userId">User ID:</label>
                    <input
                        type="text"
                        id="userId"
                        name="userId"
                        value={user.userId}
                        className="form-control readonly"
                        readOnly
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="role">Role:</label>
                    <input
                        type="text"
                        id="role"
                        name="role"
                        value={user.role}
                        className="form-control readonly"
                        readOnly
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="name">Name:</label>
                    <input
                        type="text"
                        id="name"
                        name="name"
                        value={user.name}
                        onChange={handleChange}
                        className="form-control"
                        required
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="email">Email:</label>
                    <input
                        type="email"
                        id="email"
                        name="email"
                        value={user.email}
                        onChange={handleChange}
                        className="form-control"
                        required
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="password">Password:</label>
                    <input
                        type="password"
                        id="password"
                        name="password"
                        value={user.password}
                        onChange={handleChange}
                        className="form-control"
                        required
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="mobile">Mobile Number:</label>
                    <input
                        type="text"
                        id="mobile"
                        name="mobile"
                        value={user.mobile}
                        onChange={handleChange}
                        className="form-control"
                        required
                    />
                </div>
                <button type="submit" className="btn btn-primary">
                    Save Changes
                </button>
                {success && <p className="success-message">{success}</p>}
                {error && <p className="error-message">{error}</p>}
            </form>
        </div>
    );
};

export default Profile;
