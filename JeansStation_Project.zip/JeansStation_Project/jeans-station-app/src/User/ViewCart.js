import React, { useState, useEffect } from "react";
import axios from "axios";
import "bootstrap/dist/css/bootstrap.min.css";
import { useNavigate } from "react-router-dom";
import MakeOrder from "./MakeOrder"; // Import MakeOrder component
import './ViewCart.css';

const ViewCart = () => {
  const [cartItems, setCartItems] = useState([]);
  const [error, setError] = useState("");
  const [totalPrice, setTotalPrice] = useState(0);
  const navigate = useNavigate();
  const userId = sessionStorage.getItem("userId"); // Fetch user ID from session storage

  useEffect(() => {
    if (userId) {
      fetchCartItems();
    } else {
      setError("User ID not found. Please log in.");
    }
  }, [userId]);

  const fetchCartItems = () => {
    axios
      .get(`http://localhost:5089/api/Cart/GetCartItemsDTOByUserId/${userId}`,{
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        }
      })
      .then((response) => {
        setCartItems(response.data || []); // Set empty array if no data is returned
        recalculateTotalPrice(response.data);
      })
      .catch((error) => {
        console.error("Error fetching cart items:", error);
        setError("Error fetching cart items.");
      });
  };

  const recalculateTotalPrice = (items) => {
    let total = 0;
    for (let item of items) {
      const itemTotal = (item.price - item.price * item.discount) * item.quantity;
      total += itemTotal;
    }
    setTotalPrice(total); // Update total price
  };

  const handleRemoveItem = (cartId) => {
    if (!cartId) {
      alert("Cart item ID is invalid");
      return;
    }

    axios
      .delete(`http://localhost:5089/api/Cart/DeleteCartItem?id=${cartId}`,{
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        }
      })
      .then(() => {
        fetchCartItems(); // Refresh cart items after removal
      })
      .catch((error) => {
        console.error("Error removing item from cart:", error);
        alert("Failed to remove item from cart.");
      });
  };

  const handleQuantityChange = (cartId, newQuantity) => {
    const updatedCartItems = cartItems.map((item) =>
      item.cartId === cartId
        ? {
            ...item,
            quantity: newQuantity,
            totalPrice: (item.price - item.price * item.discount) * newQuantity,
          }
        : item
    );
    setCartItems(updatedCartItems);
    recalculateTotalPrice(updatedCartItems);

    if (newQuantity > 0) {
      sessionStorage.setItem(`cartQuantity_${cartId}`, newQuantity); // Store valid quantity in session
    }
  };

  const clearCart = async () => {
    try {
      await axios.delete(`http://localhost:5089/api/Cart/ClearCart/${userId}`,{
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        }
      });
      setCartItems([]);
      setTotalPrice(0);
    } catch (error) {
      alert("Failed to clear the cart.");
    }
  };

  return (
    <div className="cart-item d-flex flex-column min-vh-100">
      

      {/* Main Content */}
      <div className="container mt-4">
        {error && <div className="alert alert-danger">{error}</div>}

        <section className="cart-list card">
          <div className="card-header bg-success text-white">
            <h3>Cart Items</h3>
          </div>
          <div className="card-body table-responsive">
            <table className="table table-striped table-bordered">
              <thead>
                <tr>
                  <th>Product Name</th>
                  <th>Size</th>
                  <th>Discount</th>
                  <th>Price</th>
                  <th>Quantity</th>
                  <th>Total Price</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {cartItems && cartItems.length > 0 ? (
                  cartItems.map((item) => (
                    <tr key={item.cartId}>
                      <td>{item.productName}</td>
                      <td>{item.size}</td>
                      <td>{item.discount}</td>
                      <td>Rs.{item.price}</td>
                      <td>
                        <input
                          type="number"
                          min="1"
                          value={item.quantity}
                          onChange={(e) => handleQuantityChange(item.cartId, parseInt(e.target.value))}
                          className="form-control"
                        />
                      </td>
                      <td>Rs{(item.price - item.price * item.discount).toFixed(2)}</td>
                      <td>
                        <button
                          className="btn btn-danger btn-sm"
                          onClick={() => handleRemoveItem(item.cartId)}
                        >
                          Remove
                        </button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="7" className="text-center">
                      No items in cart.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
            {/* Display total price */}
            <div>Total Price: Rs.{totalPrice.toFixed(2)}</div>
          </div>
        </section>

        {/* Make Order Button */}
        {cartItems.length > 0 && (
          <section className="checkout mt-4">
            <MakeOrder
              cartItems={cartItems}
              totalPrice={totalPrice}
              onOrderSuccess={clearCart} // Pass the clearCart function as a prop
            />
          </section>
        )}
      </div>
    </div>
  );
};

export default ViewCart;




