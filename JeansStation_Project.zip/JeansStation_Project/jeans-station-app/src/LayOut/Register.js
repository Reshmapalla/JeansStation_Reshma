
import React from "react";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import "./Register.css"; // Import your custom CSS

const validationSchema = Yup.object({
  name: Yup.string()
    .min(2, "Too Short!")
    .max(20, "Too Long!")
    .required("Name is required"),
  email: Yup.string()
    .email("Invalid Email Address")
    .required("Email is required"),
  mobile: Yup.string()
    .matches(/^[6-9][0-9]{9}$/, "Invalid Mobile Number")
    .required("Mobile is required"),
  role: Yup.string()
    .oneOf(["Customer", "Admin"], "Role must be either 'Customer' or 'Admin'")
    .required("Role is required"),
  password: Yup.string()
    .required("Password is required")
    .min(5, "Password must be 5 characters long")
    .matches(/^[a-z0-9]{5}$/, "Password must contain only lowercase letters and numbers"),
});

const Register = () => {
  const navigate = useNavigate();

  const save = (values, { setSubmitting, setFieldError }) => {
    const user = {
      userId: '',
      ...values
    };

    axios
      .post("http://localhost:5089/api/Authenticate/Registration", user)
      .then((res) => {
        console.log(res.data);
        setSubmitting(false);
        setTimeout(() => {
          navigate("/login");
        }, 2000);
      })
      .catch((err) => {
        console.error(err);
        setSubmitting(false);
        setFieldError("general", "Registration failed");
      });
  };

  return (
    <div className="container mt-5">
      <div className="row justify-content-center">
        <div className="col-md-8">
          <div className="card shadow-lg form-animate">
            <div className="card-header text-center bg-secondary text-white">
              <h3>Register</h3>
            </div>
            <div className="card-body p-4">
              <Formik
                initialValues={{
                  name: "",
                  email: "",
                  mobile: "",
                  role: "",
                  password: "",
                }}
                validationSchema={validationSchema}
                onSubmit={save}
              >
                {({ isSubmitting, errors }) => (
                  <Form>
                    <div className="mb-3 field-animate">
                      <label htmlFor="name" className="form-label">Name</label>
                      <Field
                        type="text"
                        name="name"
                        className="form-control input-animate"
                      />
                      <ErrorMessage name="name" component="div" className="text-danger" />
                    </div>
                    <div className="mb-3 field-animate">
                      <label htmlFor="email" className="form-label">Email</label>
                      <Field
                        type="email"
                        name="email"
                        className="form-control input-animate"
                      />
                      <ErrorMessage name="email" component="div" className="text-danger" />
                    </div>
                    <div className="mb-3 field-animate">
                      <label htmlFor="mobile" className="form-label">Mobile No.</label>
                      <Field
                        type="text"
                        name="mobile"
                        className="form-control input-animate"
                      />
                      <ErrorMessage name="mobile" component="div" className="text-danger" />
                    </div>
                    <div className="mb-3 field-animate">
                      <label htmlFor="role" className="form-label">Role</label>
                      <Field
                        as="select"
                        name="role"
                        className="form-control input-animate"
                      >
                        <option value="" label="Select role" />
                        <option value="Customer" label="Customer" />
                        <option value="Admin" label="Admin" />
                      </Field>
                      <ErrorMessage name="role" component="div" className="text-danger" />
                    </div>
                    <div className="mb-3 field-animate">
                      <label htmlFor="password" className="form-label">Password</label>
                      <Field
                        type="password"
                        name="password"
                        className="form-control input-animate"
                      />
                      <ErrorMessage name="password" component="div" className="text-danger" />
                    </div>
                    {errors.general && <div className="text-danger">{errors.general}</div>}
                    <button type="submit" className="btn btn-primary btn-animate" disabled={isSubmitting}>
                      {isSubmitting ? "Registering..." : "Register"}
                    </button>
                    <button
                      type="button"
                      className="btn btn-secondary ms-2 btn-animate"
                      onClick={() => navigate("/")}
                    >
                      Back to Home
                    </button>
                  </Form>
                )}
              </Formik>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Register;














// import React from "react";
// import { Formik, Form, Field, ErrorMessage } from "formik";
// import * as Yup from "yup";
// import axios from "axios";
// import { useNavigate } from "react-router-dom";
// import "bootstrap/dist/css/bootstrap.min.css";
// import "./Register.css"; // Import your custom CSS

// const validationSchema = Yup.object({
//   name: Yup.string()
//     .min(2, "Too Short!")
//     .max(20, "Too Long!")
//     .required("Name is required"),
//   email: Yup.string()
//     .email("Invalid Email Address")
//     .required("Email is required"),
//   mobile: Yup.string()
//     .matches(/^[6-9][0-9]{9}$/, "Invalid Mobile Number")
//     .required("Mobile is required"),
//   role: Yup.string()
//     .oneOf(["Customer", "Admin"], "Role must be either 'Customer' or 'Admin'")
//     .required("Role is required"),
//   password: Yup.string()
//     .required("Password is required")
//     .min(5, "Password must be 5 characters long")
//     .matches(/^[a-z0-9]{5}$/, "Password must contain only lowercase letters and numbers"),
// });
// // The Register component sets up the form and uses Formik for handling form state and validation.
// const Register = () => {
//   const navigate = useNavigate();

//   const save = (values, { setSubmitting, setFieldError }) => {
//     const user = {
//       userId: '',// User ID is left blank, assuming it will be generated by the backend
//       ...values // Spread operator to include all form values into the `user` object
//     };
//     // values: Contains all the form input data (e.g., name, email, password, etc.).
//     // setSubmitting: A function that can be used to set the form submission state, typically to disable the submit button while the form is being submitted.
//     // setFieldError: A function used to set error messages for specific fields if the registration fails.
//     axios
//       .post("http://localhost:5089/api/Authenticate/Registration", user)
//       .then((res) => {
//         console.log(res.data);// Logs the server response
//         setSubmitting(false);// Sets submitting state to false, allowing the form to be submitted again
//         setTimeout(() => { // Navigates to the homepage after 2 seconds
//           navigate("/login");
//         }, 2000);
//       })
//       .catch((err) => {
//         console.error(err);
//         setSubmitting(false);   // Sets submitting state to false in case of error
//         setFieldError("general", "Registration failed");
//       });
//   };

//   return (
//     <div className="register-bg d-flex flex-column min-vh-100">
//       {/* Header */}
//       <header className="bg-gradient-primary text-white py-3 text-center shadow header-animate">
//         <h1 className="display-4 title-animate text-shadow">Jeans Station</h1>
//       </header>

//       {/* Main Content */}
//       <div className="container mt-5 flex-grow-1">
//         <div className="row justify-content-center">
//           <div className="col-md-8">
//             <div className="card shadow-lg form-animate">
//               <div className="card-header text-center bg-secondary text-white">
//                 <h3>Register</h3>
//               </div>
//               <div className="card-body p-4">
//                 <Formik
//                   initialValues={{
//                     name: "",
//                     email: "",
//                     mobile: "",
//                     role: "",
//                     password: "",
//                   }}
//                   validationSchema={validationSchema}
//                   onSubmit={save}
//                 >
//                   {({ isSubmitting, errors }) => (
//                     <Form>
//                       <div className="mb-3 field-animate">
//                         <label htmlFor="name" className="form-label">Name</label>
//                         <Field
//                           type="text"
//                           name="name"
//                           className="form-control input-animate"
//                         />
//                         <ErrorMessage name="name" component="div" className="text-danger" />
//                       </div>
//                       <div className="mb-3 field-animate">
//                         <label htmlFor="email" className="form-label">Email</label>
//                         <Field
//                           type="email"
//                           name="email"
//                           className="form-control input-animate"
//                         />
//                         <ErrorMessage name="email" component="div" className="text-danger" />
//                       </div>
//                       <div className="mb-3 field-animate">
//                         <label htmlFor="mobile" className="form-label">Mobile No.</label>
//                         <Field
//                           type="text"
//                           name="mobile"
//                           className="form-control input-animate"
//                         />
//                         <ErrorMessage name="mobile" component="div" className="text-danger" />
//                       </div>
//                       <div className="mb-3 field-animate">
//                         <label htmlFor="role" className="form-label">Role</label>
//                         <Field
//                           as="select"
//                           name="role"
//                           className="form-control input-animate"
//                         >
//                           <option value="" label="Select role" />
//                           <option value="Customer" label="Customer" />
//                           <option value="Admin" label="Admin" />
//                         </Field>
//                         <ErrorMessage name="role" component="div" className="text-danger" />
//                       </div>
//                       <div className="mb-3 field-animate">
//                         <label htmlFor="password" className="form-label">Password</label>
//                         <Field
//                           type="password"
//                           name="password"
//                           className="form-control input-animate"
//                         />
//                         <ErrorMessage name="password" component="div" className="text-danger" />
//                       </div>
//                       {errors.general && <div className="text-danger">{errors.general}</div>}
//                       <button type="submit" className="btn btn-primary btn-animate" disabled={isSubmitting}>
//                         {isSubmitting ? "Registering..." : "Register"}
//                       </button>
//                       <button
//                         type="button"
//                         className="btn btn-secondary ms-2 btn-animate"
//                         onClick={() => navigate("/")}
//                       >
//                         Back to Home
//                       </button>
//                     </Form>
//                   )}
//                 </Formik>
//               </div>
//             </div>
//           </div>
//         </div>
//       </div>

//       {/* Footer */}
//       <footer className="bg-dark text-white py-3 text-center mt-auto">
//         <p>&copy; 2024 Jeans Station. All rights reserved.</p>
//       </footer>
//     </div>
//   );
// };

// export default Register;



