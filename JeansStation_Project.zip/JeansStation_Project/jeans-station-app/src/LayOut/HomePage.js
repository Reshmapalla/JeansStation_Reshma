
import React, { useState, useEffect } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import axios from "axios";
import { Link } from "react-router-dom"; // Import Link for navigation
import './HomePage.css'; // Custom CSS file for additional styling
import img1 from '../../src/Images/product.jpg';
const HomePage = () => {
  const [items, setItems] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    axios
      .get("http://localhost:5089/api/Product/GetAllProducts")
      .then((response) => {
        console.log(response);
        setItems(response.data);
        setLoading(false);
      })
      .catch((error) => {
        console.error(error);
        setError("Failed to load products.");
        setLoading(false);
      });
  }, []);

  const filteredItems = items.filter((item) =>
    item.productName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="container mt-5">
      {/* Search Input */}
      <input
        type="text"
        className="form-control w-50 mx-auto mb-4 shadow-sm search-input"
        placeholder="Search for products..."
        value={searchQuery}
        onChange={(e) => setSearchQuery(e.target.value)}
      />
      
      {/* Shop Now Button */}
      <div className="text-center mb-4">
        <Link to="/login" className="btn btn-primary">Shop Now</Link>
      </div>
      <h2 className="quote-container quote-text">
  "Discover the perfect pair of jeans that defines your style and elevates your comfort. Shop now and embrace your new favorite fit!"
</h2>


      {/* Featured Products */}
      <h2 className="text-center mb-4 text-primary animate_animated animate_fadeIn"></h2>
      {loading ? (
        <div className="text-center">
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      ) : error ? (
        <p className="text-center text-danger animate_animated animate_shakeX">{error}</p>
      ) : (
        <div className="row">
          {filteredItems.length > 0 ? (
            filteredItems.map((item) => (
              <div className="col-md-3 mb-4" key={item.productId}>
                <div className="card border-0 shadow h-100 transition-card">
                  <img
                    src={img1}
                    className="card-img-top"
                    alt={item.productName}
                    style={{ height: "200px", objectFit: "cover" }}
                  />
                  <div className="card-body text-center">
                    <h5 className="card-title">{item.productName}</h5>
                    <p className="card-text">Rs.{item.price.toFixed(2)}</p>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <p className="text-center">No products found.</p>
          )}
        </div>
      )}
    </div>
  );
};

export default HomePage;
















