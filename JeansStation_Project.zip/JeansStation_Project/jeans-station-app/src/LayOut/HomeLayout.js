
import React from "react";
import { Link, Outlet } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import "./HomeLayout.css"; // Include your custom CSS for background and styling

export default function Layout() {
  return (
    <div className="d-flex flex-column min-vh-100 bg-image">
      {/* Header / Navbar */}
      <header className="bg-dark text-white py-3 shadow sticky-top">
        <div className="container">
          <div className="d-flex justify-content-between align-items-center">
            <h1 className="logo m-0">
              <Link to="/" className="text-white text-decoration-none">
                Jeans Station
              </Link>
            </h1>
            <nav>
              <ul className="navbar-nav d-flex flex-row">
                <li className="nav-item mx-3">
                  <Link className="nav-link text-white nav-link-hover" to="home">
                    Home
                  </Link>
                </li>
                <li className="nav-item mx-3">
                  <Link className="nav-link text-white nav-link-hover" to="login">
                    Login
                  </Link>
                </li>
                <li className="nav-item mx-3">
                  <Link className="nav-link text-white nav-link-hover" to="register">
                    Register
                  </Link>
                </li>
               
              </ul>
            </nav>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container my-5">
        <Outlet />
        
      <p className="quote-author">— ShopEase Team</p>
        {/* Outlet will render specific page components */}
      </main>

      {/* Footer */}
      <footer className="footer bg-dark text-white text-center py-4 mt-auto">
        <div className="container">
          <p className="mb-0">&copy; 2024 Jeans Station. All rights reserved.</p>
          <nav className="mt-2">
            <Link to="/about" className="text-white text-decoration-none mx-3 nav-link-hover">
              About Us
            </Link>
            <Link to="/contact" className="text-white text-decoration-none mx-3 nav-link-hover">
              Contact
            </Link>
            <Link to="/help" className="text-white text-decoration-none mx-3 nav-link-hover">
              Help
            </Link>
            <Link to="/mailus" className="text-white text-decoration-none mx-3 nav-link-hover">
              Mail Us
            </Link>
          </nav>
        </div>
      </footer>
    </div>
  );
}











// import React from "react";
// import { Link, Outlet } from "react-router-dom";
// import "bootstrap/dist/css/bootstrap.min.css";
// // import "./Layout.css"; // Include your custom CSS for background and styling

// export default function Layout() {
//   return (
//     <div className="d-flex flex-column min-vh-100 bg-image">
//       {/* Header / Navbar */}
//       <header className="bg-dark text-white py-3 shadow sticky-top">
//         <div className="container">
//           <div className="d-flex justify-content-between align-items-center">
//             <h1 className="logo m-0">
//               <Link to="/" className="text-white text-decoration-none">
//                Jeans Station
//               </Link>
//             </h1>
//             <nav>
//               <ul className="navbar-nav d-flex flex-row">
//                 <li className="nav-item mx-3">
//                   <Link className="nav-link text-white" to="home">
//                     Home
//                   </Link>
//                 </li>
//                 <li className="nav-item mx-3">
//                   <Link className="nav-link text-white" to="login">
//                     Login
//                   </Link>
//                 </li>
//                 <li className="nav-item mx-3">
//                   <Link className="nav-link text-white" to="register">
//                     Register
//                   </Link>
//                 </li>
//                 <li className="nav-item mx-3">
//                   <Link className="nav-link text-white" to="contact">
//                     Contact
//                   </Link>
//                 </li>
//                 <li className="nav-item mx-3">
//                   <Link className="nav-link text-white" to="about">
//                     About
//                   </Link>
//                 </li>
//               </ul>
//             </nav>
//           </div>
//         </div>
//       </header>

//       {/* Main Content */}
//       <main className="container my-5">
//         <Outlet />
//         {/* Outlet will render specific page components */}
//       </main>

//       {/* Footer */}
//       <footer className="footer bg-dark text-white text-center py-4 mt-auto">
//         <div className="container">
//           <p className="mb-0">&copy; 2024 ShopEase. All rights reserved.</p>
//           <nav className="mt-2">
//             <Link to="/about" className="text-white text-decoration-none mx-3">
//               About Us
//             </Link>
//             <Link to="/contact" className="text-white text-decoration-none mx-3">
//               Contact
//             </Link>
//             <Link to="/help" className="text-white text-decoration-none mx-3">
//               Help
//             </Link>
//             <Link to="/mailus" className="text-white text-decoration-none mx-3">
//               Mail Us
//             </Link>
//           </nav>
//         </div>
//       </footer>
//     </div>
//   );
// }

