import React, { useEffect, useState } from 'react';
import axios from 'axios';
// import './Categories.css'; // Ensure this file is created

const Categories = () => {
    const [categories, setCategories] = useState([]);
    const [categoryName, setCategoryName] = useState("");
    const [description, setDescription] = useState("");
    const [categoryId, setCategoryId] = useState(null);
    const [isEditMode, setIsEditMode] = useState(false);
    const [error, setError] = useState("");
    const [success, setSuccess] = useState("");

    useEffect(() => {
        fetchCategories();
    }, []);

    const fetchCategories = async () => {
        try {
            const response = await axios.get('http://localhost:5089/api/Category/GetAllCategories',{
                headers: {
                  Authorization: `Bearer ${sessionStorage.getItem("token")}`,
                }
              });
            setCategories(response.data);
        } catch (error) {
            console.error('Error fetching categories:', error);
            setError('Error fetching categories.');
        }
    };

    const handleSubmit = async (event) => {
        event.preventDefault();

        try {
            if (isEditMode) {
                await axios.put('http://localhost:5089/api/Category/EditCategory', {
                    categoryId,
                    categoryName,
                    description
                },{
                    headers: {
                      Authorization: `Bearer ${sessionStorage.getItem("token")}`,
                    }
                  });
                setSuccess('Category updated successfully!');
            } else {
                await axios.post('http://localhost:5089/api/Category/AddCategory', {
                    categoryId: "someCategoryId",
                    categoryName,
                    description
                      // Ensure you provide a valid category ID
                },{
                    headers: {
                      Authorization: `Bearer ${sessionStorage.getItem("token")}`,
                    }
                  });
                setSuccess('Category added successfully!');
                setCategoryName('');
                setDescription('');
                setError('');
            }

            resetForm();
            fetchCategories();
        } catch (error) {
            console.error('Error details:', error.response ? error.response.data : error.message);
            setError('Failed to save category. Please check the input and try again.');
            setSuccess('');
        }
    };

    const handleEditCategory = (category) => {
        setCategoryName(category.categoryName);
        setDescription(category.description);
        setCategoryId(category.categoryId);
        setIsEditMode(true);
    };

    const handleDeleteCategory = async (id) => {
        if (window.confirm('Are you sure you want to delete this category?')) {
            try {
                await axios.delete(`http://localhost:5089/api/Category/DeleteCategory?id=${id}`,{
                    headers: {
                      Authorization: `Bearer ${sessionStorage.getItem("token")}`,
                    }
                  });
                fetchCategories();
            } catch (error) {
                console.error('Error deleting category:', error.response ? error.response.data : error.message);
                setError('Failed to delete category.');
            }
        }
    };

    const resetForm = () => {
        setCategoryName('');
        setDescription('');
        setCategoryId(null);
        setIsEditMode(false);
    };

    return (
        <div className="container mt-4">
            <div className="form-container mb-4 p-4 rounded shadow-sm animate_animated animate_fadeIn">
                <h2 className="mb-4">{isEditMode ? 'Update Category' : 'Add Category'}</h2>
                <form onSubmit={handleSubmit}>
                    <div className="form-group mb-3">
                        <input
                            type="text"
                            className="form-control"
                            placeholder="Category Name"
                            value={categoryName}
                            onChange={(e) => setCategoryName(e.target.value)}
                            required
                        />
                    </div>
                    <div className="form-group mb-3">
                        <input
                            type="text"
                            className="form-control"
                            placeholder="Description"
                            value={description}
                            onChange={(e) => setDescription(e.target.value)}
                            required
                        />
                    </div>
                    <button type="submit" className="btn btn-primary">
                        {isEditMode ? 'Update Category' : 'Add Category'}
                    </button>
                    {isEditMode && (
                        <button
                            type="button"
                            className="btn btn-secondary ms-2"
                            onClick={resetForm}
                        >
                            Cancel
                        </button>
                    )}
                </form>
                {success && <div className="alert alert-success mt-3 animate_animated animate_fadeIn">{success}</div>}
                {error && <div className="alert alert-danger mt-3 animate_animated animate_fadeIn">{error}</div>}
            </div>
            <h3 className="mt-5 mb-3">Categories</h3>
            <div className="table-responsive">
                <table className="table table-hover table-bordered animate_animated animate_fadeIn">
                    <thead>
                        <tr>
                            <th>Category ID</th>
                            <th>Category Name</th>
                            <th>Description</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {categories.map(category => (
                            <tr key={category.categoryId}>
                                <td>{category.categoryId}</td>
                                <td>{category.categoryName}</td>
                                <td>{category.description}</td>
                                <td>
                                    <button
                                        className="btn btn-warning btn-sm me-2"
                                        onClick={() => handleEditCategory(category)}
                                    >
                                        Edit
                                    </button>
                                    <button
                                        className="btn btn-danger btn-sm"
                                        onClick={() => handleDeleteCategory(category.categoryId)}
                                    >
                                        Delete
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default Categories;