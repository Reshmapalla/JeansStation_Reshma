
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const GetProducts = () => {
  const [items, setItems] = useState([]);
  const navigate = useNavigate(); // For redirecting to UpdateProduct

  useEffect(() => {
    axios
      .get("http://localhost:5089/api/Product/GetAllProducts", {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        },
      })
      .then((response) => {
        console.log(response.data);
        setItems(response.data); // Adding response data to items
      })
      .catch((error) => console.log(error));
  }, []);

  const Remove = (productId) => {
    // Show confirmation alert before deleting
    if (window.confirm("Are you sure you want to delete this product?")) {
      axios
        .delete(`http://localhost:5089/api/Product/DeleteProduct/${productId}`,{
          headers: {
            Authorization: `Bearer ${sessionStorage.getItem("token")}`,
          }
        })
        .then(() => {
          // Optionally refresh the list after deletion
          setItems(items.filter((item) => item.productId !== productId));
        })
        .catch((error) => console.log(error));
    }
  };

  const Update = (product) => {
    // Navigate to UpdateProduct component with product data
    navigate("/admin-dashboard/update-product", { state: { product } });
  };

  return (
    <div className="container">
      <form>
        <table className="table table-bordered table-hover">
          <thead className="table-primary">
            <tr>
              <td>Id</td>
              <td>Name</td>
              <td>Price</td>
              <td>Category</td>
              <td>Brand</td>
              <td>Color</td>
              <td>Size</td>
              <td>Discount</td>
              <td>Image</td>
              <td>Actions</td>
            </tr>
          </thead>
          <tbody>
            {items.map((i) => (
              <tr key={i.productId}>
                <td>{i.productId}</td>
                <td>{i.productName}</td>
                <td>{i.price}</td>
                <td>{i.categoryId}</td>
                <td>{i.brandId}</td>
                <td>{i.color}</td>
                <td>{i.size}</td>
                <td>{i.discount}</td>
                <td>
                  <img src={i.imageURL} alt={i.productName} width="50" />
                </td>
                <td>
                  <button
                    className="btn btn-danger"
                    onClick={() => Remove(i.productId)}
                  >
                    Delete
                  </button>
                  <button
                    className="btn btn-primary"
                    onClick={() => Update(i)} // Pass product to Update function
                  >
                    Update
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </form>
    </div>
  );
};

export default GetProducts;



















// import { useState, useEffect } from "react";
// import axios from "axios";

// const GetProducts = () => {
//   const [items, setItems] = useState([]);

//   useEffect(() => {
//     axios
//       .get("http://localhost:5089/api/Product/GetAllProducts", {
//         headers: {
//           Authorization: `Bearer ${sessionStorage.getItem("token")}`,
//         },
//       })
//       .then((response) => {
//         console.log(response.data);
//         setItems(response.data); // Adding response data to items
//       })
//       .catch((error) => console.log(error));
//   }, []);

//   const Remove = (productId) => {
//     console.log(productId);
//     axios
//       .delete(`http://localhost:5089/api/Product/DeleteProduct/${productId}`)
//       .then(() => {
//         // Optionally refresh the list after deletion
//         setItems(items.filter(item => item.productId !== productId));
//       })
//       .catch((error) => console.log(error));
//   };

//   return (
//     <div className="container">
//       <form>
//         <table className="table table-bordered table-hover">
//           <thead className="table-primary">
//             <tr>
//               <td>Id</td>
//               <td>Name</td>
//               <td>Price</td>
//               <td>Category</td>
//               <td>Brand</td>
//               <td>Color</td>
//               <td>Size</td>
//               <td>Discount</td>
//               <td>Image</td>
//               <td>Action</td>
//             </tr>
//           </thead>
//           <tbody>
//             {items.map((i) => (
//               <tr key={i.productId}>
//                 <td>{i.productId}</td>
//                 <td>{i.productName}</td>
//                 <td>{i.price}</td>
//                 <td>{i.categoryId}</td>
//                 <td>{i.brandId}</td>
//                 <td>{i.color}</td>
//                 <td>{i.size}</td>
//                 <td>{i.discount}</td>
//                 <td><img src={i.imageURL} alt={i.productName} width="50" /></td>
//                 <td>
//                   <button onClick={() => Remove(i.productId)}>Delete</button>
//                 </td>
//               </tr>
//             ))}
//           </tbody>
//         </table>
//       </form>
//     </div>
//   );
// };

// export default GetProducts;
