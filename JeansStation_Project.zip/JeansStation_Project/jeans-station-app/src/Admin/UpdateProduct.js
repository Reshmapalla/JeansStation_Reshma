
import { useState, useEffect } from "react";
import { useLocation } from "react-router-dom";
import axios from "axios";

const UpdateProduct = () => {
  const { state } = useLocation();
  const [product, setProduct] = useState({
    productId: "",
    productName: "",
    price: 0,
    categoryId: "",
    brandId: "",
    color: "",
    size: "",
    discount: 0,
    imageURL: "",
  });

  useEffect(() => {
    // Set the product data from state (passed from GetProducts)
    if (state && state.product) {
      setProduct(state.product);
    }
  }, [state]);

  const save = (e) => {
    e.preventDefault(); // Prevent default form submission
    console.log(product);
    axios
      .put("http://localhost:5089/api/Product/EditProduct", product,{
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        }
      })
      .then((res) => {
        console.log(res.data);
        alert("Product updated successfully");
      })
      .catch((err) => console.log(err));
  };

  return (
    <div className="container">
      <form onSubmit={save}> {/* Use onSubmit here */}
        <table className="table">
          <tbody>
            <tr>
              <td>Id</td>
              <td>
                <input type="text" value={product.productId} readOnly />
              </td>
            </tr>
            <tr>
              <td>Name</td>
              <td>
                <input
                  type="text"
                  value={product.productName}
                  onChange={(e) =>
                    setProduct({ ...product, productName: e.target.value })
                  }
                />
              </td>
            </tr>

             <tr>
              <td>Price</td>
              <td>
                <input
                  type="number"
                  value={product.price}
                  onChange={(e) =>
                    setProduct({ ...product, price: parseFloat(e.target.value) })
                  }
                />
              </td>
            </tr>
            <tr>
              <td>Category</td>
              <td>
                <input
                  type="text"
                  value={product.categoryId}
                  onChange={(e) =>
                    setProduct({ ...product, categoryId: e.target.value })
                  }
                />
              </td>
            </tr>
            <tr>
              <td>Brand</td>
              <td>
                <input
                  type="text"
                  value={product.brandId}
                  onChange={(e) =>
                    setProduct({ ...product, brandId: e.target.value })
                  }
                />
              </td>
            </tr>
            <tr>
              <td>Color</td>
              <td>
                <input
                  type="text"
                  value={product.color}
                  onChange={(e) =>
                    setProduct({ ...product, color: e.target.value })
                  }
                />
              </td>
            </tr>
            <tr>
              <td>Size</td>
              <td>
                <input
                  type="text"
                  value={product.size}
                  onChange={(e) =>
                    setProduct({ ...product, size: e.target.value })
                  }
                />
              </td>
            </tr>
            <tr>
              <td>Discount</td>
              <td>
                <input
                  type="number"
                  value={product.discount}
                  onChange={(e) =>
                    setProduct({ ...product, discount: parseFloat(e.target.value) })
                  }
                />
              </td>
            </tr>
            <tr>
              <td>Image URL</td>
              <td>
                <input
                  type="text"
                  value={product.imageURL}
                  onChange={(e) =>
                    setProduct({ ...product, imageURL: e.target.value })
                  }
                />
              </td>
            </tr>
            <tr>
              <td colSpan={2}>
                <button type="submit">Update</button> {/* Keep type as 'submit' */}
              </td>
            </tr>
          </tbody>
        </table>
      </form>
    </div>
  );
  
};

export default UpdateProduct;
















// import { useState } from "react";
// import axios from "axios";

// const UpdateProduct = () => {
//   const [product, setProduct] = useState({
//     productId: "",
//     productName: "",
//     price: 0,
//     categoryId: "",
//     brandId: "",
//     color: "",
//     size: "",
//     discount: 0,
//     imageURL: "",
//   });
//   const [error, setError] = useState("");

//   const save = (e) => {
//     e.preventDefault(); // Prevent default form submission
//     console.log(product);
//     axios
//       .put("http://localhost:5089/api/Product/EditProduct", product)
//       .then((res) => {
//         console.log(res.data);
//       })
//       .catch((err) => console.log(err));
//   };

//   const remove = () => {
//     axios
//       .delete(`http://localhost:5089/api/Product/DeleteProduct/${product.productId}`)
//       .then(() => {
//         // Optionally reset state or perform other actions after deletion
//       })
//       .catch((err) => console.log(err));
//   };

//   const search = (e) => {
//     e.preventDefault(); // Prevent default form submission
//     axios
//       .get(`http://localhost:5089/api/Product/GetProductById/${product.productId}`)
//       .then((res) => {
//         console.log(res);
//         if (res.data) {
//           setProduct(res.data);
//           setError(""); // Clear error if found
//         } else {
//           setError("Invalid Id");
//         }
//       })
//       .catch((err) => {
//         setError("Error fetching product");
//         console.log(err);
//       });
//   };

//   return (
//     <div className="container">
//       <form>
//         <table className="table">
//           <tbody>
//             <tr>
//               <td>Id</td>
//               <td>
//                 <input
//                   type="text"
//                   value={product.productId}
//                   onChange={(e) =>
//                     setProduct((prevObj) => ({
//                       ...prevObj,
//                       productId: e.target.value,
//                     }))
//                   }
//                 />
//               </td>
//             </tr>
//             <tr>
//               <td>Name</td>
//               <td>
//                 <input
//                   type="text"
//                   value={product.productName}
//                   onChange={(e) =>
//                     setProduct((prevObj) => ({
//                       ...prevObj,
//                       productName: e.target.value,
//                     }))
//                   }
//                 />
//               </td>
//             </tr>
//             <tr>
//               <td>Price</td>
//               <td>
//                 <input
//                   type="number"
//                   value={product.price}
//                   onChange={(e) =>
//                     setProduct((prevObj) => ({
//                       ...prevObj,
//                       price: parseFloat(e.target.value),
//                     }))
//                   }
//                 />
//               </td>
//             </tr>
//             <tr>
//               <td>Category</td>
//               <td>
//                 <input
//                   type="text"
//                   value={product.categoryId}
//                   onChange={(e) =>
//                     setProduct((prevObj) => ({
//                       ...prevObj,
//                       categoryId: e.target.value,
//                     }))
//                   }
//                 />
//               </td>
//             </tr>
//             <tr>
//               <td>Brand</td>
//               <td>
//                 <input
//                   type="text"
//                   value={product.brandId}
//                   onChange={(e) =>
//                     setProduct((prevObj) => ({
//                       ...prevObj,
//                       brandId: e.target.value,
//                     }))
//                   }
//                 />
//               </td>
//             </tr>
//             <tr>
//               <td>Color</td>
//               <td>
//                 <input
//                   type="text"
//                   value={product.color}
//                   onChange={(e) =>
//                     setProduct((prevObj) => ({
//                       ...prevObj,
//                       color: e.target.value,
//                     }))
//                   }
//                 />
//               </td>
//             </tr>
//             <tr>
//               <td>Size</td>
//               <td>
//                 <input
//                   type="text"
//                   value={product.size}
//                   onChange={(e) =>
//                     setProduct((prevObj) => ({
//                       ...prevObj,
//                       size: e.target.value,
//                     }))
//                   }
//                 />
//               </td>
//             </tr>
//             <tr>
//               <td>Discount</td>
//               <td>
//                 <input
//                   type="number"
//                   value={product.discount}
//                   onChange={(e) =>
//                     setProduct((prevObj) => ({
//                       ...prevObj,
//                       discount: parseFloat(e.target.value),
//                     }))
//                   }
//                 />
//               </td>
//             </tr>
//             <tr>
//               <td>Image URL</td>
//               <td>
//                 <input
//                   type="text"
//                   value={product.imageURL}
//                   onChange={(e) =>
//                     setProduct((prevObj) => ({
//                       ...prevObj,
//                       imageURL: e.target.value,
//                     }))
//                   }
//                 />
//               </td>
//             </tr>
//             <tr>
//               <td colSpan={2}>
//                 <button type="submit" onClick={save}>Edit</button>
//                 <button type="button" onClick={remove}>Delete</button>
//                 <button type="button" onClick={search}>Search</button>
//               </td>
//             </tr>
//             <tr>
//               <td colSpan={2}>
//                 <span>{error}</span>
//               </td>
//             </tr>
//           </tbody>
//         </table>
//       </form>
//     </div>
//   );
// };

// export default UpdateProduct;

