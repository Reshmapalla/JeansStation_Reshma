import React, { useEffect, useState } from 'react';
import axios from 'axios';
// import './GetAllUsers.css'; // Import the custom CSS file for additional styling

const GetAllUsers = () => {
    const [users, setUsers] = useState([]);
    const [error, setError] = useState("");
    const [success, setSuccess] = useState("");

    useEffect(() => {
        const fetchUsers = async () => {
            try {
                const response = await axios.get('http://localhost:5089/api/Authenticate/GetAllUsers',{
                    headers: {
                      Authorization: `Bearer ${sessionStorage.getItem("token")}`,
                    }
                  });
                setUsers(response.data);
            } catch (err) {
                setError('Failed to fetch users');
                console.error(err);
            }
        };
        fetchUsers();
    }, []);

    const deleteUser = async (userId) => {
        try {
            await axios.delete(`http://localhost:5089/api/Authenticate/DeleteUser?id=${userId}`,{
                headers: {
                  Authorization: `Bearer ${sessionStorage.getItem("token")}`,
                }
              });
            setSuccess('User deleted successfully');
            setUsers(users.filter(user => user.userId !== userId));
        } catch (err) {
            setError('Failed to delete user');
            console.error(err);
        }
    };

    return (
        <div className="container mt-5 get-all-users-container">
            <h2 className="mb-4 text-center text-uppercase">All Users</h2>
            {error && <div className="alert alert-danger">{error}</div>}
            {success && <div className="alert alert-success">{success}</div>}
            {users.length > 0 ? (
                <div className="table-responsive">
                    <table className="table table-hover table-bordered">
                        <thead className="thead-dark">
                            <tr>
                                <th>UserId</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Mobile</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {users.map(user => (
                                <tr key={user.userId}>
                                    <td>{user.userId}</td>
                                    <td>{user.name}</td>
                                    <td>{user.email}</td>
                                    <td>{user.role}</td>
                                    <td>{user.mobile}</td>
                                    <td>
                                        <button 
                                            onClick={() => deleteUser(user.userId)} 
                                            className="btn btn-danger btn-sm"
                                        >
                                            Delete
                                        </button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            ) : (
                <p className="text-center">No users found.</p>
            )}
        </div>
    );
};

export default GetAllUsers;