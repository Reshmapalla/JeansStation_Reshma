import { useState } from "react";
import axios from "axios";
import "bootstrap/dist/css/bootstrap.min.css";
import "./AddProduct.css"; // Import your CSS file

const AddProduct = () => {
  const [product, setProduct] = useState({
    productId: "",
    productName: "",
    price: 0,
    categoryId: "",
    brandId: "",
    color: "",
    size: "",
    discount: 0,
    imageURL: "",
  });

  const save = (e) => {
    e.preventDefault();
    console.log(product);
    axios
      .post("http://localhost:5089/api/Product/AddProduct", product,{
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        }
      })
      .then((res) => {
        console.log(res.data);
        alert("Product added successfully");
      })
      .catch((err) => console.log(err));
  };

  return (
    <div className="add-product-container">
      <form className="add-product-form" onSubmit={save}>
        <table>
          <tbody>
            <tr>
              <td>Product Name</td>
              <td>
                <input
                  type="text"
                  value={product.productName}
                  onChange={(e) =>
                    setProduct((prevObj) => ({
                      ...prevObj,
                      productName: e.target.value,
                    }))
                  }
                />
              </td>
            </tr>
            <tr>
              <td>Price</td>
              <td>
                <input
                  type="number"
                  value={product.price}
                  onChange={(e) =>
                    setProduct((prevObj) => ({
                      ...prevObj,
                      price: parseFloat(e.target.value),
                    }))
                  }
                />
              </td>
            </tr>
            <tr>
              <td>Category ID</td>
              <td>
                <input
                  type="text"
                  value={product.categoryId}
                  onChange={(e) =>
                    setProduct((prevObj) => ({
                      ...prevObj,
                      categoryId: e.target.value,
                    }))
                  }
                />
              </td>
            </tr>
            <tr>
              <td>Brand ID</td>
              <td>
                <input
                  type="text"
                  value={product.brandId}
                  onChange={(e) =>
                    setProduct((prevObj) => ({
                      ...prevObj,
                      brandId: e.target.value,
                    }))
                  }
                />
              </td>
            </tr>
            <tr>
              <td>Color</td>
              <td>
                <input
                  type="text"
                  value={product.color}
                  onChange={(e) =>
                    setProduct((prevObj) => ({
                      ...prevObj,
                      color: e.target.value,
                    }))
                  }
                />
              </td>
            </tr>
            <tr>
              <td>Size</td>
              <td>
                <input
                  type="text"
                  value={product.size}
                  onChange={(e) =>
                    setProduct((prevObj) => ({
                      ...prevObj,
                      size: e.target.value,
                    }))
                  }
                />
              </td>
            </tr>
            <tr>
              <td>Discount</td>
              <td>
                <input
                  type="number"
                  value={product.discount}
                  onChange={(e) =>
                    setProduct((prevObj) => ({
                      ...prevObj,
                      discount: parseFloat(e.target.value),
                    }))
                  }
                />
              </td>
            </tr>
            <tr>
              <td>Image URL</td>
              <td>
                <input
                  type="text"
                  value={product.imageURL}
                  onChange={(e) =>
                    setProduct((prevObj) => ({
                      ...prevObj,
                      imageURL: e.target.value,
                    }))
                  }
                />
              </td>
            </tr>
            <tr>
              <td colSpan={2}>
                <button type="submit">Save</button>
              </td>
            </tr>
          </tbody>
        </table>
      </form>
    </div>
  );
};

export default AddProduct;














// import { useState } from "react";
// import axios from "axios";
// import "bootstrap/dist/css/bootstrap.min.css";
// // import "./AddProduct.css"

// const AddProduct = () => {
//   const [product, setProduct] = useState({
//     productId: "",
//     productName: "",
//     price: 0,
//     categoryId: "",
//     brandId: "",
//     color: "",
//     size: "",
//     discount: 0,
//     imageURL: "",
//   });

//   const save = (e) => {
//     e.preventDefault();
//     console.log(product);
//     axios
//       .post("http://localhost:5089/api/Product/AddProduct", product)
//       .then((res) => {
//         console.log(res.data);
//         alert("Product added successfully");
//       })
//       .catch((err) => console.log(err));
//   };

//   return (
//     <div className="container">
//       <form onSubmit={save}>
//         <table className="table">
//           <tbody>
           
//             <tr>
//               <td>Product Name</td>
//               <td>
//                 <input
//                   type="text"
//                   value={product.productName}
//                   onChange={(e) =>
//                     setProduct((prevObj) => ({
//                       ...prevObj,
//                       productName: e.target.value,
//                     }))
//                   }
//                 />
//               </td>
//             </tr>
//             <tr>
//               <td>Price</td>
//               <td>
//                 <input
//                   type="number"
//                   value={product.price}
//                   onChange={(e) =>
//                     setProduct((prevObj) => ({
//                       ...prevObj,
//                       price: parseFloat(e.target.value),
//                     }))
//                   }
//                 />
//               </td>
//             </tr>
//             <tr>
//               <td>Category ID</td>
//               <td>
//                 <input
//                   type="text"
//                   value={product.categoryId}
//                   onChange={(e) =>
//                     setProduct((prevObj) => ({
//                       ...prevObj,
//                       categoryId: e.target.value,
//                     }))
//                   }
//                 />
//               </td>
//             </tr>
//             <tr>
//               <td>Brand ID</td>
//               <td>
//                 <input
//                   type="text"
//                   value={product.brandId}
//                   onChange={(e) =>
//                     setProduct((prevObj) => ({
//                       ...prevObj,
//                       brandId: e.target.value,
//                     }))
//                   }
//                 />
//               </td>
//             </tr>
//             <tr>
//               <td>Color</td>
//               <td>
//                 <input
//                   type="text"
//                   value={product.color}
//                   onChange={(e) =>
//                     setProduct((prevObj) => ({
//                       ...prevObj,
//                       color: e.target.value,
//                     }))
//                   }
//                 />
//               </td>
//             </tr>
//             <tr>
//               <td>Size</td>
//               <td>
//                 <input
//                   type="text"
//                   value={product.size}
//                   onChange={(e) =>
//                     setProduct((prevObj) => ({
//                       ...prevObj,
//                       size: e.target.value,
//                     }))
//                   }
//                 />
//               </td>
//             </tr>
//             <tr>
//               <td>Discount</td>
//               <td>
//                 <input
//                   type="number"
//                   value={product.discount}
//                   onChange={(e) =>
//                     setProduct((prevObj) => ({
//                       ...prevObj,
//                       discount: parseFloat(e.target.value),
//                     }))
//                   }
//                 />
//               </td>
//             </tr>
//             <tr>
//               <td>Image URL</td>
//               <td>
//                 <input
//                   type="text"
//                   value={product.imageURL}
//                   onChange={(e) =>
//                     setProduct((prevObj) => ({
//                       ...prevObj,
//                       imageURL: e.target.value,
//                     }))
//                   }
//                 />
//               </td>
//             </tr>
//             <tr>
//               <td colSpan={2}>
//                 <button type="submit">Save</button>
//               </td>
//             </tr>
//           </tbody>
//         </table>
//       </form>
//     </div>
//   );
// };

// export default AddProduct;
