import React, { useEffect, useState } from 'react';
import axios from 'axios';

const Brands = () => {
    const [brands, setBrands] = useState([]);
    const [brandName, setBrandName] = useState("");
    const [brandId, setBrandId] = useState(null);
    const [isEditMode, setIsEditMode] = useState(false);
    const [error, setError] = useState("");
    const [success, setSuccess] = useState("");

    useEffect(() => {
        fetchBrands();
    }, []);

    const fetchBrands = async () => {
        try {
            const response = await axios.get('http://localhost:5089/api/Brand/GetAllBrands', {
                headers: {
                  Authorization: `Bearer ${sessionStorage.getItem("token")}`,
                },
              });
            setBrands(response.data);
        } catch (error) {
            console.error('Error fetching brands:', error);
            setError('Error fetching brands.');
        }
    };

    const handleSubmit = async (event) => {
        event.preventDefault();

        try {
            if (isEditMode) {
                await axios.put('http://localhost:5089/api/Brand/EditBrand', {
                    brandId,
                    brandName
                }, {
                    headers: {
                      Authorization: `Bearer ${sessionStorage.getItem("token")}`,
                    },
                  });
                setSuccess('Brand updated successfully!');
            } else {
                await axios.post('http://localhost:5089/api/Brand/AddBrand', {
                    brandId: "B" + Math.floor(1000 + Math.random() * 9000), // Generating a random brand ID
                    brandName
                }, {
                    headers: {
                      Authorization: `Bearer ${sessionStorage.getItem("token")}`,
                    },
                  });
                setSuccess('Brand added successfully!');
                setBrandName('');
                setError('');
            }

            resetForm();
            fetchBrands();
        } catch (error) {
            console.error('Error details:', error.response ? error.response.data : error.message);
            setError('Failed to save brand. Please check the input and try again.');
            setSuccess('');
        }
    };

    const handleEditBrand = (brand) => {
        setBrandName(brand.brandName);
        setBrandId(brand.brandId);
        setIsEditMode(true);
    };

    const handleDeleteBrand = async (id) => {
        if (window.confirm('Are you sure you want to delete this brand?')) {
            try {
                await axios.delete(`http://localhost:5089/api/Brand/DeleteBrand?id=${id}`,{
                    headers: {
                      Authorization: `Bearer ${sessionStorage.getItem("token")}`,
                    }
                  });
                fetchBrands();
            } catch (error) {
                console.error('Error deleting brand:', error.response ? error.response.data : error.message);
                setError('Failed to delete brand.');
            }
        }
    };

    const resetForm = () => {
        setBrandName('');
        setBrandId(null);
        setIsEditMode(false);
    };

    return (
        <div className="container mt-4">
            <div className="form-container mb-4 p-4 rounded shadow-sm animate_animated animate_fadeIn">
                <h2 className="mb-4">{isEditMode ? 'Update Brand' : 'Add Brand'}</h2>
                <form onSubmit={handleSubmit}>
                    <div className="form-group mb-3">
                        <input
                            type="text"
                            className="form-control"
                            placeholder="Brand Name"
                            value={brandName}
                            onChange={(e) => setBrandName(e.target.value)}
                            required
                        />
                    </div>
                    <button type="submit" className="btn btn-primary">
                        {isEditMode ? 'Update Brand' : 'Add Brand'}
                    </button>
                    {isEditMode && (
                        <button
                            type="button"
                            className="btn btn-secondary ms-2"
                            onClick={resetForm}
                        >
                            Cancel
                        </button>
                    )}
                </form>
                {success && <div className="alert alert-success mt-3 animate_animated animate_fadeIn">{success}</div>}
                {error && <div className="alert alert-danger mt-3 animate_animated animate_fadeIn">{error}</div>}
            </div>
            <h3 className="mt-5 mb-3">Brands</h3>
            <div className="table-responsive">
                <table className="table table-hover table-bordered animate_animated animate_fadeIn">
                    <thead>
                        <tr>
                            <th>Brand ID</th>
                            <th>Brand Name</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {brands.map(brand => (
                            <tr key={brand.brandId}>
                                <td>{brand.brandId}</td>
                                <td>{brand.brandName}</td>
                                <td>
                                    <button
                                        className="btn btn-warning btn-sm me-2"
                                        onClick={() => handleEditBrand(brand)}
                                    >
                                        Edit
                                    </button>
                                    <button
                                        className="btn btn-danger btn-sm"
                                        onClick={() => handleDeleteBrand(brand.brandId)}
                                    >
                                        Delete
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default Brands;
