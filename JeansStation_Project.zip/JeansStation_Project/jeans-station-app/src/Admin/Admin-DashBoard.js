import React, { useState, useEffect } from "react";
import { Link, Outlet } from "react-router-dom";

const AdminDashboard = () => {
  const [uname, setUname] = useState("");

  useEffect(() => {
    const u = sessionStorage.getItem("uname"); // Retrieve the username from session storage
    setUname(u || ""); // Set uname, defaulting to an empty string if null
  }, []);

  return (
    <div className="d-flex flex-column min-vh-100">
      <header className="bg-dark text-white py-2 shadow">
        <div className="container">
          <div className="d-flex justify-content-between align-items-center">
            <h1>Admin Dashboard</h1>
            <nav>
              <ul className="navbar-nav d-flex flex-row">
                <li className="nav-item mx-2">
                  <Link className="nav-link text-white" to="/home">
                    Home
                  </Link>
                </li>
               
                
                
                <li className="nav-item mx-2">
                  <Link className="nav-link text-white" to="getall">
                    View Products
                  </Link>
                </li>
                <li className="nav-item mx-2">
                  <Link className="nav-link text-white" to="add">
                    Add Products
                  </Link>
                </li>
                <li className="nav-item mx-2">
                  <Link className="nav-link text-white" to="category">
                    Categories
                  </Link>
                </li>
                <li className="nav-item mx-2">
                  <Link className="nav-link text-white" to="brand">
                    Brands
                  </Link>
                </li>
                <li className="nav-item mx-2">
                  <Link className="nav-link text-white" to="getallusers">
                    Users
                  </Link>
                </li>
                <li className="nav-item mx-2">
                  <Link className="nav-link text-white" to="adminorderdetails">
                    Orders
                  </Link>
                </li>
                <li className="nav-item mx-2">
                  <Link className="nav-link text-white" to="/login">
                    Log Out
                  </Link>
                </li>
                <li className="nav-item mx-2">
                  <Link className="nav-link text-white" to="profile">
                    Profile
                  </Link>
                </li>
              </ul>
            </nav>
          </div>
        </div>
      </header>
      <main className="flex-grow-1">
        <Outlet />
      </main>
      <footer className="bg-dark text-white text-center py-3 mt-auto">
        <div className="container">
          <p>&copy; 2024 ShopEase. All rights reserved.</p>
          <p>
            <Link to="/about" className="text-white text-decoration-none">
              About Us
            </Link>{" "}
            |{" "}
            <Link to="/contact" className="text-white text-decoration-none">
              Contact
            </Link>{" "}
            |{" "}
            <Link to="/help" className="text-white text-decoration-none">
              Help
            </Link>{" "}
            |{" "}
            <Link to="/mailus" className="text-white text-decoration-none">
              Mail Us
            </Link>
          </p>
        </div>
      </footer>
    </div>
  );
};

export default AdminDashboard;





