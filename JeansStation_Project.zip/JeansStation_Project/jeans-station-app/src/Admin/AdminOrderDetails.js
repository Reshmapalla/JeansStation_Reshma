
import React, { useEffect, useState } from "react";
import axios from "axios";
import "bootstrap/dist/css/bootstrap.min.css";
import "./AdminOrderDetails.css";

const AdminOrderDetails = () => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [error, setError] = useState(null);

  const fetchOrders = async (startDate = null, endDate = null) => {
    try {
      setLoading(true); // Ensure loading is set to true when fetching starts
      let url = "http://localhost:5089/api/Order/GetAllOrdersForAdmin";

      if (startDate && endDate) {
        const formattedStartDate = new Date(startDate).toISOString().split("T")[0];
        const formattedEndDate = new Date(endDate).toISOString().split("T")[0];
        url = `http://localhost:5089/api/Order/GetOrdersByDateRange?startDate=${formattedStartDate}&endDate=${formattedEndDate}`;
      }
      const token = sessionStorage.getItem("token"); // Retrieve token from sessionStorage
      const response = await axios.get(url,{
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        }
      });
      if (response.data) {
        setOrders(response.data); // Ensure orders are set
      } else {
        setOrders([]); // If no data, set an empty array
      }
      setLoading(false);
    } catch (error) {
      console.error("Error fetching orders", error);
      setError("An error occurred while fetching orders");
      setOrders([]);
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOrders();
  }, []);

  const handleSearch = () => {
    fetchOrders(startDate, endDate);
  };

  if (loading) {
    return <p>Loading orders...</p>;
  }

  if (error) {
    return <p>{error}</p>;
  }

  return (
    <div className="container">
      <h2>All User Orders</h2>

      {/* Date Range Filter */}
      <div className="date-filter">
        <input
          type="date"
          value={startDate}
          onChange={(e) => setStartDate(e.target.value)}
        />
        <input
          type="date"
          value={endDate}
          onChange={(e) => setEndDate(e.target.value)}
        />
        <button className="btn btn-primary" onClick={handleSearch}>
          Search 
        </button>
      </div>

      {orders && orders.length === 0 ? (
        <p>No orders found.</p>
      ) : (
        <div className="order-list">
          {orders && orders.map((order) => (
            <div key={order.orderId} className="card mb-4">
              <div className="card-header">
                <h5>
                  Order #{order.orderId} - {order.userName} (Rs.{order.totalPrice.toFixed(2)})
                </h5>
                <p>Order Date: {new Date(order.orderDate).toLocaleDateString()}</p>
              </div>

              <div className="card-body">
                <div className="row">
                  {/* Order Information */}
                  <div className="col-md-6">
                    <h6>Order Information</h6>
                    <p><strong>Address:</strong> {order.address}</p>
                    <p><strong>Status:</strong> {order.orderStatus}</p>
                    <p><strong>Delivery Date:</strong> {new Date(order.deliveryDate).toLocaleDateString()}</p>
                  </div>

                  {/* Transaction Details */}
                  <div className="col-md-6">
                    <h6>Transaction Details</h6>
                    <p><strong>Method:</strong> {order.transactionMethod}</p>
                    <p><strong>Status:</strong> {order.transactionStatus}</p>
                    <p><strong>Date:</strong> {new Date(order.transactionDate).toLocaleDateString()}</p>
                  </div>
                </div>

                {/* Order Items Table */}
                <h6>Order Items</h6>
                <table className="table table-sm table-bordered">
                  <thead>
                    <tr>
                      <th>Product Name</th>
                      <th>Quantity</th>
                      <th>Unit Price</th>
                      <th>Total Price</th>
                    </tr>
                  </thead>
                  <tbody>
                    {order.orderItems && order.orderItems.map((item) => (
                      <tr key={item.productId}>
                        <td>{item.productName}</td>
                        <td>{item.quantity}</td>
                        <td>Rs.{item.unitPrice.toFixed(2)}</td>
                        <td>Rs.{item.totalPrice.toFixed(2)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default AdminOrderDetails;





















// import React, { useEffect, useState } from "react";
// import axios from "axios";
// import "bootstrap/dist/css/bootstrap.min.css";
// import "./AdminOrderDetails.css";

// const AdminOrderDetails = () => {
//   const [orders, setOrders] = useState([]);
//   const [loading, setLoading] = useState(true);

//   useEffect(() => {
//     const fetchOrders = async () => {
//       try {
//         const response = await axios.get("http://localhost:5089/api/Order/GetAllOrdersForAdmin");
//         setOrders(response.data);
//         setLoading(false);
//       } catch (error) {
//         console.error("Error fetching orders", error);
//         setLoading(false);
//       }
//     };

//     fetchOrders();
//   }, []);

//   if (loading) {
//     return <p>Loading orders...</p>;
//   }

//   return (
//     <div className="container">
//       <h2>All User Orders</h2>
//       {orders.length === 0 ? (
//         <p>No orders found.</p>
//       ) : (
//         <div className="order-list">
//           {orders.map((order) => (
//             <div key={order.orderId} className="card mb-4">
//               <div className="card-header">
//                 <h5>Order #{order.orderId} - {order.userName} (${order.totalPrice.toFixed(2)})</h5>
//                 <p>Order Date: {new Date(order.orderDate).toLocaleDateString()}</p>
//               </div>

//               <div className="card-body">
//                 <div className="row">
//                   {/* Order Information */}
//                   <div className="col-md-6">
//                     <h6>Order Information</h6>
//                     <p><strong>Address:</strong> {order.address}</p>
//                     <p><strong>Status:</strong> {order.orderStatus}</p>
//                     <p><strong>Delivery Date:</strong> {new Date(order.deliveryDate).toLocaleDateString()}</p>
//                   </div>

//                   {/* Transaction Details */}
//                   <div className="col-md-6">
//                     <h6>Transaction Details</h6>
//                     <p><strong>Method:</strong> {order.transactionMethod}</p>
//                     <p><strong>Status:</strong> {order.transactionStatus}</p>
//                     <p><strong>Date:</strong> {new Date(order.transactionDate).toLocaleDateString()}</p>
//                   </div>
//                 </div>

//                 {/* Order Items Table */}
//                 <h6>Order Items</h6>
//                 <table className="table table-sm table-bordered">
//                   <thead>
//                     <tr>
//                       <th>Product Name</th>
//                       <th>Quantity</th>
//                       <th>Unit Price</th>
//                       <th>Total Price</th>
//                     </tr>
//                   </thead>
//                   <tbody>
//                     {order.orderItems.map((item) => (
//                       <tr key={item.productId}>
//                         <td>{item.productName}</td>
//                         <td>{item.quantity}</td>
//                         <td>${item.unitPrice.toFixed(2)}</td>
//                         <td>${item.totalPrice.toFixed(2)}</td>
//                       </tr>
//                     ))}
//                   </tbody>
//                 </table>
//               </div>
//             </div>
//           ))}
//         </div>
//       )}
//     </div>
//   );
// };

// export default AdminOrderDetails;




