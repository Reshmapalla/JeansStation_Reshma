import './App.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import HomePage from './LayOut/HomePage';
import Login from './LayOut/Login';
import Register from './LayOut/Register';
import UserDashboard from './User/UserDashBoard';
import ViewCart from './User/ViewCart';
import Transaction from './User/Transaction';
import AdminDashboard from './Admin/Admin-DashBoard';
import GetProducts from './Admin/GetAllProducts';
import UpdateProduct from './Admin/UpdateProduct';
import AddProduct from './Admin/AddProduct';
import Categories from './Admin/Category';
import User from './User/UserLayOut';
import Layout from './LayOut/HomeLayout';
import GetAllUsers from './Admin/GetAllUsers';
import OrderDetails from './User/OrderDetails';
import AdminOrderDetails from './Admin/AdminOrderDetails';
import Profile from './User/Profile';
import Brands from './Admin/Brands';

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          {/* Anonymous User */}
          <Route path="/" element={<Layout />} >
          <Route path="home" element={<HomePage />} />
          <Route path="login" element={<Login />} />
          <Route path="register" element={<Register />} />
          </Route>
    
          {/* Admin Dashboard */}
          <Route path="admin-dashboard" element={<AdminDashboard />}>
            {/* Nested Routes for Admin */}
            <Route path="getall" element={<GetProducts />} />
            {/* Update Product without URL parameter, data passed via state */}
            <Route path="update-product" element={<UpdateProduct />} />
            <Route path="getallusers" element={<GetAllUsers />} />
            <Route path="add" element={<AddProduct />} />
            <Route path="category" element={<Categories />} />
            <Route path="brand" element={<Brands />}/>
            <Route path="adminorderdetails" element={<AdminOrderDetails />} />
            <Route path="profile" element={<Profile/>} />
            
          </Route>

          {/* User Dashboard */}
          <Route path="user-layout" element={<User/>} >
          <Route path="user-dashboard" element={<UserDashboard />} />
          <Route path="cart" element={<ViewCart />} />
          <Route path="transaction" element={<Transaction/>} />
          <Route path="orderdetails" element={<OrderDetails/>} />
          <Route path="profile" element={<Profile/>} />
          </Route>
          {/* <Route path="user-dashboard/tran" element={<Transaction />} /> */}
        </Routes>
      </BrowserRouter>

    </div>
  );
}

export default App;
